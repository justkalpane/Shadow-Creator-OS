---
name: aruna-pipeline-orchestrator-v3
description: >
  PRD v3.0.0 Pipeline Orchestrator. Full state machine for 16 skills.
  Manages Content Dossier, two human pause points, parallel execution tracks,
  error handling protocols, and final delivery report.
  Trigger: full pipeline, make complete video, start to finish, run everything.
---

# ☀️ ARUNA — Pipeline Orchestrator v3.0.0
> *PRD §4.3 — Agent Orchestration System*
> *"Charioteer of the Sun God. 7 horses = 7 phases. He holds every rein simultaneously."*

---

## ARUNA'S PRINCIPLE

KRISHNA is the architect. ARUNA is the executor.

ARUNA does not create content. He **manages the Content Dossier**, tracks module state, routes data between skills, handles failures, and keeps the pipeline moving toward the 45-minute end-to-end target.

16 skills are his horses. They only run when ARUNA holds the correct rein at the correct moment.

---

## COMPLETE PIPELINE — ARUNA'S MASTER SEQUENCE

```
SHADOW AI EMPIRE — FULL PRODUCTION PIPELINE v3.0.0
══════════════════════════════════════════════════════════════════════════
[KRISHNA]  Boot: load registry, health check, init Dossier, set routing map

PHASE A — INTELLIGENCE (~5 min, parallel)
  ├── NARADA (01)    → Topic research, virality score ≥ 6.0, content brief
  └── BRAHMA (13)    → Cinematic background prompts per script section [NEW]

PHASE B — SCRIPT (~2 min)
  └── BRIHASPATI (02) → Script: emotion-tagged, SSML, Flesch ≥ 60, 3 hook variants

PHASE C — PRODUCTION PREP (parallel, ~3 min + human action)
  ├── SARASWATI (03)  → 4 ElevenLabs variant prep + chunking + SSML clean
  ├── MAYA (04)       → Thumbnail 8-layer prompt + 3 B-roll prompts
  └── TVASHTAR (14)   → Cinematic reference photos from BRAHMA briefs [NEW]

  ⏸ PAUSE POINT 1: VOICE GENERATION
     User action: Generate 4 audio variants in ElevenLabs (~5–10 min)
     ARUNA status: "Waiting for audio. Take your time — I'll prep the next phase."

PHASE D — AVATAR RENDER (waitForTaskToken, 20–35 min zero-cost wait)
  └── VISHWAKARMA (08) → HeyGen POST → task_token → wait

  PARALLEL DURING RENDER WAIT (ARUNA activates all simultaneously):
  ├── NATARAJA (11)   → Emotion curve from tagged script (~200ms estimate)
  ├── GARUDA (05)     → Complete SEO package (title, desc, tags, chapters)
  ├── SANJAY (07)     → Edit decision list + Shorts plan
  └── VARUNA (15)     → Background video generation from TVASHTAR photos [NEW]

  ⏸ PAUSE POINT 2: HEYGEN DOWNLOAD
     User action: Download rendered avatar video from HeyGen (~5 min)
     ARUNA status: "Download complete? All parallel work finished while you waited."

PHASE E — ASSEMBLY (~10–15 min)
  ├── RENDER-FORGE (12) → FFmpeg 3-step: merge audio → encode 1080p → Shorts 9:16
  ├── AGNI (16)         → Master cinema edit: 3-sec rule, B-roll, sound, captions [NEW]
  └── SHAKUNI (09)      → Adversarial QA gate (≥ 7.0 qa_score required)
                            IF REVISE/REJECT → loop to repair module → retry max 3×

PHASE F — DELIVERY
  └── GARUDA (05) → YouTube Data API v3 resumable upload → metadata → schedule

PHASE G — LEARNING (next session, 24h post-publish)
  └── GANESHA (06) → Analytics pull → feedback weights → improve next video

TARGET: ≤ 45 minutes end-to-end (PRD FR-03)
══════════════════════════════════════════════════════════════════════════
```

---

## THE TWO HUMAN PAUSE POINTS (DETAIL)

### ⏸ PAUSE 1 — VOICE GENERATION

```
ARUNA SAYS: "⏸ Pipeline paused. Your action needed."

WHAT CLAUDE PREPARED:
  → Cleaned script (SSML only, [EMOTION] tags stripped)
  → ElevenLabs settings for all 4 variants
  → Chunk split points (if script > 4,800 chars)
  → Voice ID confirmed from USER_CONFIG.md

YOUR ACTION (3 steps):
  1. Go to: elevenlabs.io → your cloned voice
  2. Paste cleaned script (Chunk 1 if multiple)
  3. Set sliders: [variant-specific values]
  4. Generate → Download MP3
  5. Save to: _outputs/audio_[variant]_final.mp3
  6. Repeat for all chunks/variants as instructed

TIME: 5–10 minutes

WHEN DONE: Type "audio ready" or "voice done"
ARUNA RESUMES: Routes audio to VISHWAKARMA
```

### ⏸ PAUSE 2 — HEYGEN RENDER + DOWNLOAD

```
ARUNA SAYS: "⏸ HeyGen is rendering. I'm working while you wait."

WHAT CLAUDE PREPARED:
  → Complete HeyGen step-by-step instructions (from VISHWAKARMA)
  → Presigned HTTPS audio URL (or local file path)
  → Emotion expression setting recommendation (from NATARAJA)

YOUR ACTION (HeyGen website):
  1. heygen.com → Create Video → Avatar Video
  2. Select your avatar
  3. Voice: Upload Audio → select audio_[variant]_final.mp3
  4. Background: Upload reference photo from TVASHTAR (optional)
  5. Resolution: 1920×1080 | Test: OFF
  6. Click Generate

  WAIT: 20–35 minutes

  7. ⚠ DOWNLOAD IMMEDIATELY when status = "Complete"
     (HeyGen URLs expire in ~7 days — download NOW)
  8. Save as: _outputs/avatar_video_raw.mp4

WHILE YOU WAIT, ARUNA RUNS:
  → NATARAJA: emotion curve generation
  → GARUDA: full SEO package
  → SANJAY: edit decision list
  → VARUNA: background video prompts

WHEN DONE: Type "video ready" or "HeyGen done"
ARUNA RESUMES: Routes to RENDER-FORGE → AGNI → SHAKUNI
```

---

## ERROR HANDLING PROTOCOLS

### PROTOCOL 1 — THE LOOP BACK (QA Rejection)

```
IF SHAKUNI verdict = REVISE or REJECT:
  1. Read rejection_codes from Dossier
  2. Identify highest priority repair module
  3. Route to repair with shakuni_notes
  4. Increment dossier.retry_count
  5. IF retry_count ≥ 3: KRISHNA ALERT-02
  
  Rejection routing examples:
    QA-01 (lip sync)    → VISHWAKARMA: "New render, try ENERGETIC variant"
    QA-02 (audio)       → SARASWATI: "Switch from calm to master variant"
    QA-03 (visual)      → VISHWAKARMA: "New HeyGen session"
    QA-04A (hook weak)  → BRIHASPATI: "Rewrite hook only, keep body"
    QA-04E (3-sec rule) → AGNI: "Add zoom cuts in failing windows"
    QA-05A (background) → TVASHTAR: "Regenerate with Runway instead of Pika"
```

### PROTOCOL 2 — THE SILENCE PROTOCOL (API Timeout)

```
IF any module does not complete within 30 minutes:
  → Trigger KRISHNA ALERT-01
  → Attempt retry (up to 3× total)
  → On 3rd failure: activate fallback
      ElevenLabs timeout → Provide Murf.ai or PlayHT alternative instructions
      HeyGen timeout → Switch to D-ID fallback (VISHWAKARMA)
      HeyGen quality fail → SadTalker on HuggingFace (free)
      Runway timeout → Switch to Pika Labs
  → Notify user in plain English: what failed, exact next action
```

### PROTOCOL 3 — PARALLEL EFFICIENCY (The Time Multiplier)

```
WHILE VISHWAKARMA renders (20–35 min wait):
  Execute simultaneously:
    Promise.all([
      NATARAJA.generateEmotionCurve(dossier),      // ~200ms
      GARUDA.buildSEOPackage(dossier),              // ~2 min
      SANJAY.buildEditDecisionList(dossier),        // ~2 min
      VARUNA.generateBackgroundVideos(dossier)      // ~5–10 min
    ])
  
  Result: 4 tasks complete during render wait = ~15 min parallel work
  Net time saved: ~15 minutes per video cycle
  PRD target met: ≤ 45 min total (render wait is the bottleneck, not the work)
```

---

## ARUNA'S PSEUDOCODE (PRD §4.3 Reference)

```javascript
// ARUNA — Master Pipeline Orchestrator v3.0.0
async function runPipeline(userCommand) {

  // KRISHNA initializes the chariot
  const dossier = await KRISHNA.initialize(userCommand);

  try {
    // ═══ PHASE A — INTELLIGENCE ═══════════════════════════
    const [topic, background_prompts] = await Promise.all([
      NARADA.researchAndScore(dossier),
      BRAHMA.generateScenePrompts(dossier)  // runs parallel with NARADA
    ]);
    dossier.topic = topic;                   // gate: topic_score ≥ 6.0
    dossier.background_prompts = background_prompts;

    // ═══ PHASE B — SCRIPT ═════════════════════════════════
    dossier.script = await BRIHASPATI.write(dossier);  // gate: flesch ≥ 60

    // ═══ PHASE C — PRODUCTION PREP ════════════════════════
    const [voice_prep, thumbnails, ref_photos] = await Promise.all([
      SARASWATI.prepareVoice(dossier),
      MAYA.generateVisuals(dossier),
      TVASHTAR.generateReferencePhotos(dossier)
    ]);

    // ⏸ PAUSE POINT 1 — Human generates audio in ElevenLabs
    dossier.selected_audio_url = await aruna.pauseForHuman("VOICE_GENERATION", dossier);

    // ═══ PHASE D — AVATAR RENDER + PARALLEL WORK ══════════
    const [avatar_video, emotion_curve, seo, edit_plan, bg_videos] = await Promise.all([
      aruna.pauseForHuman("HEYGEN_RENDER", dossier),  // Human action
      NATARAJA.generateEmotionCurve(dossier),          // Parallel
      GARUDA.buildSEOPackage(dossier),                 // Parallel
      SANJAY.buildEditPlan(dossier),                   // Parallel
      VARUNA.generateBackgroundVideos(dossier)         // Parallel [NEW]
    ]);

    // ═══ PHASE E — ASSEMBLY ═══════════════════════════════
    dossier.rendered_video = await RENDER_FORGE.assemble(dossier);  // FFmpeg 3-step
    dossier.edited_video = await AGNI.masterEdit(dossier);          // 3-sec rule [NEW]

    // QA GATE — Retry loop
    let qa_result = await SHAKUNI.inspect(dossier);
    let retry = 0;
    while (qa_result.verdict !== "APPROVED" && retry < 3) {
      dossier = await aruna.loopBack(qa_result.rejection_codes, dossier);
      dossier.edited_video = await AGNI.masterEdit(dossier);
      qa_result = await SHAKUNI.inspect(dossier);
      retry++;
    }
    if (retry >= 3 && qa_result.verdict !== "APPROVED") {
      KRISHNA.alert("ALERT-02", dossier);  // Human review needed
    }

    // ═══ PHASE F — DELIVERY ═══════════════════════════════
    dossier.youtube_video_id = await GARUDA.upload(dossier);

    // ═══ PHASE G — LEARNING (next session) ════════════════
    await GANESHA.scheduleAnalytics(dossier, ["24h", "48h", "7d", "28d"]);

    return aruna.deliveryReport(dossier);

  } catch (error) {
    KRISHNA.notifyArchitect(error);  // Divine Alert
  }
}
```

---

## PIPELINE STATUS BOARD

```
ARUNA STATUS — Job: [SHADOW-XXXXXXXX]
════════════════════════════════════════════════════
Topic: [topic] | Started: [timestamp]

  ✅ KRISHNA      Initialized. 16 skills active.
  ✅ NARADA       "[topic]" | Score: [X.X/10]
  ✅ BRAHMA       [X] scene backgrounds architected
  ✅ BRIHASPATI   [X] words | Flesch: [X] | Hook: [type]
  ✅ SARASWATI    4 variants prepped | Dominant: [variant]
  ✅ MAYA         Thumbnail prompt + [X] B-roll prompts
  ✅ TVASHTAR     [X] reference photos generated
  ⏳ WAITING      PAUSE POINT 1: Generate audio in ElevenLabs
  ⬜ VISHWAKARMA  Pending audio
  ⬜ NATARAJA     Pending (runs during HeyGen render)
  ⬜ VARUNA       Pending (runs during HeyGen render)
  ⬜ GARUDA SEO   Pending (runs during HeyGen render)
  ⬜ SANJAY       Pending (runs during HeyGen render)
  ⬜ RENDER-FORGE Not started
  ⬜ AGNI         Not started
  ⬜ SHAKUNI      Not started
  ⬜ GARUDA UPLOAD Not started
  ⬜ GANESHA      Post-publish (24h)

CURRENT ACTION: ⏸ [Exact user instruction in plain English]
Pipeline: [X]% complete | Est. remaining: ~[X] min
════════════════════════════════════════════════════
```

---

## FINAL DELIVERY REPORT

```
☀️ ARUNA — PIPELINE COMPLETE — v3.0.0
════════════════════════════════════════════════════════
Job: [SHADOW-XXXXXXXX] | Duration: [X hr X min]

QUALITY SCORES:
  Lip Sync:   [X.XX] (gate: ≥0.75) ✅
  SSIM:       [X.XX] (gate: ≥0.85) ✅
  QA Score:   [X.X/10] (gate: ≥7.0) ✅
  Emotion r²: [X.XX] (gate: ≥0.80) ✅

DELIVERABLES:
  ✅ Script:              [X] words | [emotion] | [hook_type]
  ✅ Audio:               [variant] variant | [X]s
  ✅ Background photos:   [X] cinematic scenes (TVASHTAR)
  ✅ Background videos:   [X] clips (VARUNA)
  ✅ Avatar video:        [X]s raw MP4
  ✅ Final 1080p:         [X]s edited | [X] edit events | [X]% 3-sec rule
  ✅ Shorts 9:16:         [X]s vertical
  ✅ Captions:            SRT file ready
  ✅ Thumbnail:           8-layer cinematic prompt ready
  ✅ SEO Package:         Title + description + [X] tags + chapters
  ✅ QA: APPROVED         by SHAKUNI

COST:
  Render: ~$0.025 | ElevenLabs: plan/month | Total this video: ~$[X]

NEXT: Upload to YouTube using GARUDA's package.
THEN: In 24h, type "check analytics" for GANESHA.
════════════════════════════════════════════════════════
```

> *"The sun rises because ARUNA holds the reins. The Empire publishes because ARUNA holds the pipeline."*
