---
name: render-forge-video-assembly-v3
description: >
  PRD v3.0.0 Video Generation Engine. FFmpeg 3-step pipeline: merge audio, encode 1080p,
  generate 9:16 Shorts. Fargate container spec. Exact FFmpeg commands from PRD §3.4.
  Trigger: FFmpeg render, video assembly, create final video, encode video.
---

# ⚙️ RENDER-FORGE — Video Assembly Engine v3.0.0
> *PRD §3.4 — Video Generation Engine*
> *"5–10 min on 2-vCPU Fargate. $0.025/render. H.264 CRF 23. +faststart for instant streaming."*

---

## ENGINE SPECIFICATION (PRD §3.4)

| Property | Value |
|---|---|
| Engine | FFmpeg (Amazon Linux 2023, dnf repo — no custom build needed) |
| Container | AWS Fargate: 2 vCPU / 4 GB RAM |
| Why Fargate, not Lambda | Lambda 15-min hard limit. FFmpeg 1080p encode takes 5–12 min |
| Input 1 | avatar_video.mp4 (from VISHWAKARMA, S3 URI) |
| Input 2 | voice_master.mp3 (from SARASWATI, S3 URI) |
| Output 1 | final_1080p.mp4 — H.264 CRF 23, AAC 192k, +faststart |
| Output 2 | shorts_1080x1920.mp4 — center-crop 9:16, 1080×1920 |
| Average render time | 5–10 minutes (2-vCPU Fargate) |
| Cost per render | ~$0.025 (8 min × $0.04048/vCPU-hr × 2 vCPU) |
| Cache headers | Cache-Control: public, max-age=31536000, immutable (1-year CDN) |

---

## 3-STEP FFMPEG PIPELINE — EXACT COMMANDS (PRD §3.4)

### STEP 1 — AUDIO MERGE
*Replace HeyGen's embedded audio with ElevenLabs cloned voice. Copy video stream (no re-encode).*

```bash
ffmpeg -i avatar_video_raw.mp4 \
       -i voice_master_final.mp3 \
       -c:v copy \          # Copy video stream unchanged — fast, no quality loss
       -c:a aac \           # Re-encode audio to AAC
       -b:a 192k \          # 192kbps audio bitrate
       -map 0:v:0 \         # Video: from avatar_video (stream 0)
       -map 1:a:0 \         # Audio: from voice_master (stream 1)
       -shortest \          # Trim to shorter of video/audio
       merged.mp4
```

**Why this step:** HeyGen renders with its own embedded audio. We replace it with the ElevenLabs cloned voice for emotional accuracy.

### STEP 2 — H.264 ENCODE
*Production-quality encode with web streaming optimization.*

```bash
ffmpeg -i merged.mp4 \
       -c:v libx264 \       # H.264 codec (maximum compatibility)
       -preset fast \       # Balance speed vs compression
       -crf 23 \            # CRF 23: high quality, ~40% smaller than lossless
       -c:a copy \          # Audio already AAC from step 1 — copy it
       -movflags +faststart \ # Move moov atom to file start → instant streaming
       final_1080p.mp4
```

**Why +faststart:** Without this flag, YouTube and browsers must download the entire file before playback starts. +faststart enables instant streaming.

### STEP 3 — SHORTS REFORMAT
*Center-crop landscape 16:9 to vertical 9:16 for YouTube Shorts/TikTok/Reels.*

```bash
ffmpeg -i final_1080p.mp4 \
       -vf "crop=ih*9/16:ih:(iw-ih*9/16)/2:0,scale=1080:1920" \
       # crop=width:height:x_offset:y_offset
       # width = ih*9/16 (crop width to 9:16 ratio based on height)
       # x_offset = (iw-ih*9/16)/2 (center the crop horizontally)
       # scale=1080:1920 (final output size for Shorts native)
       -c:v libx264 \
       -preset fast \
       shorts_1080x1920.mp4
```

**Output sizes:**
- `final_1080p.mp4` → 1920×1080 (YouTube standard landscape)
- `shorts_1080x1920.mp4` → 1080×1920 (Shorts/TikTok/Reels native vertical)

---

## BACKGROUND VIDEO COMPOSITING (NEW — for VARUNA outputs)

When VARUNA has generated background videos, add a 4th step:

### STEP 4 — COMPOSITE AVATAR OVER BACKGROUND (Optional)

```bash
# Composite avatar (green screen removed) over cinematic background video
ffmpeg -i background_video.mp4 \            # VARUNA output (background)
       -i avatar_video_raw.mp4 \            # VISHWAKARMA output (avatar)
       -filter_complex \
       "[0:v][1:v] overlay=0:0" \           # Avatar overlaid on background
       -c:v libx264 -preset fast \
       -crf 23 avatar_with_background.mp4

# If avatar has green screen background, add chromakey first:
# [1:v] chromakey=0x00FF00:0.1:0.2 [avatar_clean];
# [0:v][avatar_clean] overlay=0:0
```

---

## S3 OUTPUT KEYS (PRD §3.4)

```
jobs/{job_id}/final/final_1080p.mp4
jobs/{job_id}/final/shorts_1080x1920.mp4

CDN URLS (after CloudFront distribution):
  https://cdn.shadowai.com/jobs/{job_id}/final/final_1080p.mp4
  https://cdn.shadowai.com/jobs/{job_id}/final/shorts_1080x1920.mp4

CACHE POLICY:
  Cache-Control: public, max-age=31536000, immutable
  Reason: Videos never change after production. 1-year cache = zero CDN cost on repeat views.
```

---

## LOCAL/FREE RENDERING METHOD (No Fargate)

For users without AWS, use FFmpeg locally (100% free):

```
INSTALL FFMPEG (FREE):
  Mac:     brew install ffmpeg
  Windows: ffmpeg.org → download → add to PATH
  Linux:   sudo apt install ffmpeg

RUN THE 3-STEP PIPELINE:
  Step 1: [Run Step 1 command above in Terminal]
  Step 2: [Run Step 2 command above in Terminal]
  Step 3: [Run Step 3 command above in Terminal]

ALTERNATIVE — CapCut (Zero code, free):
  1. Open CapCut Desktop
  2. Import avatar_video_raw.mp4
  3. Add audio_master_final.mp3 to audio track
  4. Mute original video audio
  5. Export as: 1080p, H.264, AAC
  6. For Shorts: Change canvas to 9:16, scale/reframe avatar
```

---

## QUALITY VERIFICATION (PRD §2.7)

After render, verify with ffprobe:

```bash
ffprobe -v error -show_streams -show_format final_1080p.mp4

Expected values:
  width:       1920
  height:      1080
  codec_name:  h264
  r_frame_rate: 30/1  (30fps)
  bit_rate:    2000000–5000000 (2–5 Mbps, good range)
  duration:    matches audio_duration_sec (within ±2s)
```

---

## RENDER TIMING (PRD §2.5)

| Stage | Duration |
|---|---|
| Fargate task start | ~30 seconds |
| Step 1: Audio merge | ~20 seconds (video copy, fast) |
| Step 2: H.264 encode | 4–8 minutes (2-vCPU) |
| Step 3: Shorts crop | ~1–2 minutes |
| S3 upload (1080p ~500MB) | ~90 seconds |
| **Total** | **~7–13 minutes** |

---

## SAVE + HAND OFF

Update Dossier: `final_1080p_url`, `shorts_url`, `cdn_1080p_url`, `cdn_shorts_url`, `render_cost_usd`.

> "✅ RENDER-FORGE: Video assembled. 1080p and Shorts ready on CDN.
> Next: AGNI for master edit (sound design, zoom cuts, B-roll), then SHAKUNI for QA."
