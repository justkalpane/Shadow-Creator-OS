---
name: agni-master-cinema-editor-v3
description: >
  NEW SKILL §14. PRD §3.6 Editing Engine. Takes all outputs from Skills 11-13 plus
  avatar video and applies industry-level editing: 3-second retention rule, programmatic
  zoom cuts, B-roll insertion, sound design, transitions, captions, end screens.
  Trigger: master edit, cinema edit, post-production, add sound effects, final cut.
---

# 🔥 AGNI — Master Cinema Editor v3.0.0
> *PRD §3.6 — Editing Engine · "The Fire That Transforms Raw Material Into Refined Gold"*
> *"The 3-second retention rule is not a guideline. It is a law."*

---

## AGNI'S DOMAIN — COMPLETE EDITING STACK (PRD §3.6)

AGNI receives ALL upstream outputs and applies the complete editing stack:

```
INPUTS REQUIRED:
  final_1080p.mp4        (RENDER-FORGE — avatar + voice merged)
  emotion_curve.json     (NATARAJA — timestamps + emotion intensity)
  script                 (BRIHASPATI — text with [EMOTION] tags)
  background_videos/     (VARUNA — per-scene cinematic backgrounds)
  reference_photos/      (TVASHTAR — per-scene reference stills)
  thumbnail_prompt       (MAYA — thumbnail visual direction)
  edit_decision_log      (SANJAY — narrative cut plan)
  audio_master.mp3       (SARASWATI — clean voice audio)

OUTPUTS DELIVERED:
  master_edited_1080p.mp4       (YouTube upload ready)
  master_shorts_1080x1920.mp4   (Shorts upload ready)
  captions.srt                  (subtitle file)
  edit_log.json                 (full edit manifest)
```

---

## THE 3-SECOND RETENTION RULE (PRD §3.6 — Core Algorithm)

*Every 3 seconds of video must contain at least one visual or audio edit event.*

```python
# 3-SECOND RETENTION RULE — PROGRAMMATIC IMPLEMENTATION (PRD §3.6 exact)
# Source: emotion_curve.json from NATARAJA

peaks = [t for t in curve if t['intensity'] > 0.65]

for window_start in range(0, duration, 3):
    window_events = [p for p in peaks 
                     if window_start <= p['t'] < window_start + 3]
    
    if not window_events:
        # No natural peak in this 3-second window
        # Insert zoom cut at window midpoint
        add_zoom_cut(window_start + 1.5, scale=1.10, duration=0.3)
```

**In plain language:**
- Scan emotion_curve.json for intensity spikes > 0.65
- Check every 3-second window
- If a window has NO spike → **insert automatic zoom cut at the 1.5s mark**
- Scale: 1.10 (10% zoom punch — noticeable but not jarring)
- Duration: 0.3 seconds (fast punch, snap back)

**Target:** 95%+ of 3-second windows must contain an edit event.

---

## COMPLETE EDIT TYPES — IMPLEMENTATION GUIDE (PRD §3.6)

### EDIT 1 — AUTO-CAPTIONS (AWS Transcribe / CapCut)

```
METHOD A — AWS Transcribe (Cloud):
  1. Submit audio_master.mp3 to transcribe.start_transcription_job()
  2. Wait ~45 seconds for completion
  3. Download transcript JSON → convert to .srt format
  4. Burn into video with FFmpeg:
     ffmpeg -i final_1080p.mp4 -vf "subtitles=captions.srt:force_style=
     'FontName=Montserrat,FontSize=18,Bold=1,PrimaryColour=&Hffffff,
     OutlineColour=&H000000,Outline=3,Alignment=2'" -c:a copy captioned.mp4

METHOD B — CapCut (Free, Zero Code):
  1. Import final_1080p.mp4 into CapCut
  2. Text → Auto Captions → Language: English → Generate
  3. Select all captions → Style: Bold, Centered, Large
  4. Color: White with black outline
  5. Export 1080p

CAPTION STYLE SPEC:
  Font:       Montserrat ExtraBold / Impact / Bebas Neue
  Size:       Large (readable at 120px thumbnail preview)
  Color:      White #FFFFFF, 3px black outline
  Emphasis:   Yellow #FFD700 for key terms
  Position:   Lower-center, never blocking face
  Style:      Word-by-word flash for hooks, sentence-blocks for body
```

### EDIT 2 — ZOOM CUTS (Programmatic)

```
ZOOM CUT SPECIFICATION:
  Trigger: emotion_intensity > 0.65 OR 3-second rule enforcement
  Scale:   1.10 (10% push in) — noticeable, not jarring
  Speed:   0.2–0.3 seconds in / snap back 0.1 seconds out
  Max:     Never zoom > 1.15 (anything more looks cheap)
  
FFMPEG ZOOM IMPLEMENTATION:
  ffmpeg -i input.mp4 -vf "zoompan=z='if(lte(on\,30),1+on/150,max(pzoom,zoom)-0.015):
  d=1:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1920x1080,scale=1920:1080"
  output_zoom.mp4

CAPCUT METHOD (Free):
  1. Split clip at zoom trigger timestamp
  2. Select clip section → Scale to 110% → Keyframe smooth-in
  3. Duration of scaled section: 0.3–0.5 seconds
  4. Snap back to 100%
```

### EDIT 3 — B-ROLL INSERTION FROM VARUNA

```
B-ROLL PLACEMENT LOGIC:
  Trigger points (from script analysis):
    → Keyword/concept introduction (first mention of key term)
    → Every VISUAL_ILLUSTRATION section in script formula
    → Any [IMPACTFUL] tag with supporting visual
    → BRAHMA scenes designated as B-roll windows

INSERTION METHOD (DaVinci Resolve / CapCut):
  1. Place background video (VARUNA output) on Video Track 2
  2. Avatar video stays on Video Track 1 (ALWAYS on top)
  3. Set Track 2 opacity to [0% → 100% → 0%] at insertion point
  4. Duration: match script illustration point (typically 3–8 seconds)
  5. Cross-dissolve transition: 0.3–0.5 seconds in/out

COMPOSITING (Avatar over cinematic background):
  Layer order (bottom to top):
    Track 1: VARUNA background video
    Track 2: Avatar video (avatar must have clean/solid background from HeyGen)
    Track 3: Caption text
    Track 4: Sound effect markers
    Track 5: Title cards / text overlays
```

### EDIT 4 — SOUND DESIGN (PRD §3.6)

```
SOUND EFFECTS MAP:
  [IMPACTFUL] tag → impact sound at phoneme onset
    Sound: bass thump / whoosh / impact hit
    Timing: 0ms before first word of [IMPACTFUL] sentence
    Volume: -12dB under voice (felt, not heard)

  Key statistic → subtle "data ping" sound
  Section transition → 0.3s atmospheric transition sound
  Hook open → brief music sting (0.5–1.5 seconds)
  CTA moment → upbeat resolution sound

MUSIC DUCKING (PRD §3.6):
  Background music baseline: -18 to -20dB
  B-roll sections (no voice): -12dB
  Impact moments: Brief swell to -10dB → snap back to -18dB
  Intro/outro: -6dB

FREE SOUND LIBRARIES:
  Freesound.org — Creative Commons sounds
  Zapsplat.com — Professional free tier
  Pixabay.com/sound-effects — No attribution needed
  YouTube Audio Library — Free
```

### EDIT 5 — TITLE CARDS (PRD §3.6)

```
TITLE CARD PLACEMENT:
  Lower third:  First 5 seconds — speaker name + episode title
  Section cards: At each script section transition (0.3s fade in/out)
  Key stat:     Hold 3 seconds on screen during [IMPACTFUL] stat
  Quote:        Pull quote from script peak moment — large centered text

TITLE CARD DESIGN:
  Font: Montserrat Bold or similar
  Background: semi-transparent dark bar (#000000, 70% opacity)
  Text: White #FFFFFF
  Accent line: Thin horizontal line in brand color
  Animation: Slide-in from left (0.2s), fade-out (0.3s)
```

### EDIT 6 — END SCREEN (PRD §3.6)

```
END SCREEN — LAST 20 SECONDS:
  Elements: Subscribe button, Next video card, Channel logo
  Background: Semi-dark overlay on avatar (not total black)
  Text: "[Subscribe for weekly AI insights]" + "[Watch this next]"
  Duration: Final 20 seconds (YouTube end-screen standard)

FFmpeg end card overlay:
  ffmpeg -i main_video.mp4 -i end_screen_template.png
  -filter_complex "[0:v][1:v] overlay=0:0:enable='gte(t,{end_time-20})'"
  -c:a copy final_with_endscreen.mp4
```

---

## EDIT DECISION LOG — FULL FORMAT

```json
EDIT LOG — [TOPIC] — Job: [SHADOW-XXXXXXXX]
{
  "total_edits": 0,
  "zoom_cuts": [],
  "broll_insertions": [],
  "sound_events": [],
  "title_cards": [],
  "caption_style": "",
  "retention_score": 0.0,
  
  "3sec_compliance": {
    "total_windows": 0,
    "covered_windows": 0,
    "compliance_pct": 0.0
  },
  
  "timeline": [
    {
      "t": 0.0,
      "event_type": "ZOOM_CUT",
      "trigger": "3sec_rule",
      "scale": 1.10,
      "duration": 0.3
    },
    {
      "t": 4.8,
      "event_type": "BROLL_INSERT",
      "source": "varuna_scene2.mp4",
      "duration": 5.0,
      "blend": "dissolve_0.5s"
    },
    {
      "t": 7.2,
      "event_type": "SOUND_EFFECT",
      "sound": "impact_hit.mp3",
      "volume_db": -12,
      "trigger": "[IMPACTFUL]"
    }
  ]
}
```

---

## EDITING TOOL COMPARISON

| Tool | Cost | 3-Sec Rule | B-roll | Captions | Export |
|---|---|---|---|---|---|
| **CapCut Desktop** | Free | Manual | Manual | Auto ✅ | 4K |
| **DaVinci Resolve** | Free | Timeline | Full ✅ | Auto ✅ | Professional |
| **Adobe Premiere** | $55/mo | Timeline | Full ✅ | Auto ✅ | Professional |
| **Submagic** | $15/mo | N/A | N/A | Auto ✅ | 1080p |
| **FFmpeg** | Free | Code ✅ | Code ✅ | Burn ✅ | Any format |

**Recommended workflow:** CapCut Desktop (free) for the full edit. DaVinci Resolve for color grading.

---

## AGNI'S MASTER EDIT CHECKLIST

```
PRE-EXPORT QUALITY CHECK:
  □ 3-second retention rule: every window has an event
  □ Captions: every word visible, no overlap with face
  □ Audio levels: voice clear at -6dB RMS, music at -18dB
  □ B-roll: all transitions smooth (no jump cuts)
  □ End screen: last 20 seconds have subscribe CTA
  □ Zoom cuts: never > 1.15 scale
  □ Sound effects: all at -12dB or below (supporting, not dominating)
  □ Color: consistent grade, no exposure jumps
  □ Duration: matches target length ±10%
  □ File size: 1080p under 4GB for YouTube (typically 200–800MB)
```

---

## SHORTS SPECIFIC RULES (PRD §3.6)

```
SHORTS EDIT REQUIREMENTS:
  Duration:     Maximum 60 seconds
  Format:       9:16 vertical (1080×1920)
  Hook:         First 3 seconds MUST have text overlay stating the value
  Captions:     Mandatory (70% watch muted)
  End:          "Watch full video ↑" text in last 3 seconds
  Music:        Optional but recommended (check copyright)
  Pacing:       Faster cuts than long-form (avg 2–3 sec per shot)
  B-roll:       Use VARUNA clips in vertical crop mode
```

---

## SAVE + HAND OFF

Update Dossier: `master_edited_video`, `shorts_edited_video`, `captions_srt`, `retention_score`, `edit_log`.

> "🔥 AGNI: Master edit complete. [X] edit events. 3-sec rule: [X]% compliant.
> Captions burned. Sound design applied. End screen inserted.
> Next: SHAKUNI for final QA gate before upload."
