---
name: vishwakarma-avatar-engine-v3
description: >
  PRD v3.0.0 Avatar Clone Engine. Full HeyGen API spec with exact request structure.
  waitForTaskToken pattern, EventBridge 60s polling, URL TTL enforcement.
  D-ID fallback, SadTalker self-hosted fallback.
  Trigger: render avatar, HeyGen, lip sync, avatar video.
---

# 🔨 VISHWAKARMA — Avatar Clone Engine v3.0.0
> *PRD §3.1 — Avatar Clone Engine*
> *"HeyGen render: 20–35 min. Cost during wait: $0.00. Pattern: waitForTaskToken."*

---

## AVATAR REALISM REQUIREMENTS (PRD FR-01)

| Requirement | Specification | Verification Method |
|---|---|---|
| Lip Sync Accuracy | Phoneme-frame alignment ≤ 40ms | Wav2Lip confidence score ≥ 0.92 |
| Facial Expression Range | 6 base emotions + micro-variants | Emotion classifier ≥ 88% |
| Eye Behaviour | Natural blink 12–20/min, gaze drift | Manual QA + eye tracking |
| Head Motion | Natural pose variation ±15° yaw/pitch | Pose estimation ≥ 0.90 |
| Skin Realism | No texture artifacts, consistent lighting | SSIM score ≥ 0.85 vs reference |
| Resolution | 1080p minimum, 4K target | ffprobe width/height validation |

---

## SOURCE MATERIAL REQUIREMENTS (PRD §2.3)

```
AVATAR TRAINING VIDEO SPEC
════════════════════════════════════════════
Training video:   2–5 minutes, 1080p minimum
Lighting:         Soft frontal (ring light or window), NO hard shadows
Frame:            Head + shoulders, centered, eye-level camera
Background:       Solid neutral color OR chroma key green
NO distractions:  no jewelry movement, no background motion

UPLOAD TO: heygen.com → Avatars → Instant Avatar → Upload video
WAIT: Avatar processing takes 15–30 minutes after upload
```

---

## HEYGEN API REQUEST — EXACT STRUCTURE (PRD §3.1)

```json
POST https://api.heygen.com/v1/video_generate
Headers: { "X-Api-Key": "{heygen_api_key}" }

{
  "video_inputs": [{
    "character": {
      "type": "avatar",
      "avatar_id": "{your_avatar_id}",
      "avatar_style": "normal"
    },
    "voice": {
      "type": "audio",              // CRITICAL: MUST be "audio" NOT "text"
      "audio_url": "{presigned_url}" // CRITICAL: MUST be HTTPS, NOT s3://
    }
  }],
  "dimension": {
    "width": 1920,                  // 1080p landscape
    "height": 1080
  },
  "test": false                     // false = production quality render
}
```

**⚠ TWO CRITICAL REQUIREMENTS (PRD §3.1):**
1. `voice.type` MUST be `"audio"` — NOT `"text"`. Using "text" ignores your cloned voice.
2. `audio_url` MUST be an HTTPS presigned URL — NOT `s3://...`. HeyGen cannot access S3 URIs.

---

## WAITFORTASKTOKEN PATTERN (PRD §3.1 — Zero Cost Wait)

```
HEYGEN RENDER LIFECYCLE:
════════════════════════════════════════════════════════
1. VISHWAKARMA submits job → HeyGen returns task_id
2. Step Functions PAUSES with .waitForTaskToken
   (SFN execution suspended = $0.00 cost during wait)
3. EventBridge rule fires every 60 seconds
4. Lambda:avatar_poller → queries HeyGen status API
   GET https://api.heygen.com/v1/video_status/{task_id}
5. When status = "completed":
   a. Extract video_url from response
   b. DOWNLOAD IMMEDIATELY (URL expires in ~7 days!)
   c. Upload to S3: jobs/{job_id}/avatar/raw.mp4
   d. Send task_success to Step Functions callback
6. Step Functions RESUMES from pause point
   Total wait cost: $0.00
   HeyGen render time: 20–35 min average
```

---

## URL TTL ENFORCEMENT (PRD §1.3 + §3.1)

```
⚠ CRITICAL: HeyGen video URLs expire in approximately 7 days.
   Dead links cause silent failures downstream.

RULE: ALWAYS download the video to S3 IMMEDIATELY on render completion.
NEVER store the HeyGen URL as the final reference.
NEVER return the HeyGen URL to end users.
ONLY return CloudFront CDN URLs after S3 upload.

IMMEDIATE DOWNLOAD PROCEDURE:
  response_url = heygen_status["video_url"]      # expires ~7 days
  r = httpx.get(response_url, follow_redirects=True)
  s3.put_object(
      Bucket=ASSETS_BUCKET,
      Key=f"jobs/{job_id}/avatar/raw.mp4",
      Body=r.content
  )
  # Only AFTER successful S3 upload → mark job AVATAR_COMPLETE
```

---

## POLLING STRATEGY (PRD §3.1)

```
POLLING ARCHITECTURE:
  EventBridge: rate(60 seconds) → Lambda:avatar_poller
  
  avatar_poller logic:
    1. Query DynamoDB status-index for AVATAR_SUBMITTED jobs
    2. For each job: GET heygen status API
    3. If status = "processing": log timestamp, continue
    4. If status = "completed":
       a. Download video to S3
       b. Update DynamoDB → AVATAR_COMPLETE
       c. step_functions.send_task_success(taskToken, videoUrl)
    5. If status = "failed":
       a. Update DynamoDB → AVATAR_FAILED
       b. step_functions.send_task_failure(taskToken, error)
       c. Trigger D-ID fallback
```

---

## FALLBACK CHAIN (PRD §3.1)

```
FALLBACK HIERARCHY:
  Primary:     HeyGen Custom Avatar (20–35 min, highest quality)
  Fallback 1:  D-ID API (pay-per-use ~$0.05/video, faster, lower realism)
  Fallback 2:  SadTalker self-hosted (Hugging Face Spaces, free, open-source)
  Fallback 3:  Wav2Lip + still image (minimal, but functional)
```

### D-ID FALLBACK STEPS (Website Method)
```
1. Go to: d-id.com → Create Video → Talking Avatar
2. Upload face photo (1080p, front-facing, neutral expression)
3. Upload audio file from SARASWATI
4. Set: "Animated" mode for more expression
5. Generate → Download MP4
Cost: ~$0.05/video on pay-per-use plan
```

### SADTALKER FALLBACK (Free, HuggingFace)
```
1. Go to: huggingface.co/spaces → search "SadTalker"
2. Upload: avatar face photo + audio file
3. Set: expression_scale = 1.5 (more expressive), preprocess = "full"
4. Generate → Download
Cost: $0.00
Quality: Lower than HeyGen, but fully functional
```

---

## MULTIPLE AVATAR PROFILES (PRD §3.1 Scaling)

```
PHASE 3 AVATAR LIBRARY (DynamoDB):
  Profile 1: "Tech Host"     → avatar_id_tech,    professional studio look
  Profile 2: "News Host"     → avatar_id_news,    formal, desk setting
  Profile 3: "Explainer"     → avatar_id_explain, casual, friendly tone
  Profile 4: "Expert"        → avatar_id_expert,  authoritative, suit

  Selection logic: dominant_emotion → matching avatar style
    ENERGETIC/IMPACTFUL → Tech Host or Explainer
    SERIOUS → Expert or News Host
    CALM/CONSPIRATORIAL → Explainer
```

---

## WEBSITE METHOD (Non-Technical, No API)

```
HEYGEN WEBSITE STEPS:
════════════════════════════════════════════
1. heygen.com → Log in
2. Create Video → Avatar Video
3. Select your custom avatar
4. Voice section: Click "Upload Audio"
   → Upload: audio_{variant}_final.mp3 from SARASWATI
   → DO NOT type text — use audio upload
5. Background: upload a reference photo from TVASHTAR (optional)
6. Resolution: 1080p | Aspect ratio: 16:9
7. Click Generate
8. Wait 20–35 minutes
9. IMMEDIATELY DOWNLOAD the MP4 when done
10. Save as: _outputs/avatar_video_raw.mp4
```

---

## SAVE + HAND OFF

Update Dossier: `avatar_video_url`, `heygen_task_id`, `render_duration_sec`.

> "✅ VISHWAKARMA: Avatar video downloaded to S3/local.
> ⚠ Reminder: HeyGen URL already expired protection active — using S3 copy only.
> Next: NATARAJA for emotion curve (if not done), then RENDER-FORGE for FFmpeg assembly."
