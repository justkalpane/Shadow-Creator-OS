---
name: garuda-youtube-publishing-v3
description: >
  PRD v3.0.0 YouTube Deployment Engine. YouTube Data API v3, resumable upload,
  3-variant title SEO scoring, description 3-zone format, tag strategy.
  Quota: 1600 units/upload, 10K daily limit. Chapter timestamps. Scheduling.
  Trigger: upload YouTube, publish video, SEO package, write description, write title.
---

# 🦅 GARUDA — YouTube Publishing Engine v3.0.0
> *PRD §3.7 — YouTube Deployment Engine · §2.6 YouTube Growth Engine*
> *"The Divine Eagle carries the payload directly to the summit."*

---

## YOUTUBE DATA API v3 — UPLOAD SPEC (PRD §3.7)

```python
# RESUMABLE UPLOAD (handles large files + network interruptions)
import googleapiclient.discovery
import googleapiclient.http

youtube = googleapiclient.discovery.build('youtube', 'v3',
    credentials=credentials)  # OAuth2 from Secrets Manager

request = youtube.videos().insert(
    part="snippet,status",
    body={
        "snippet": {
            "title": seo_title,              # 50–60 chars, keyword-first
            "description": description,       # 3-zone format below
            "tags": tags,                     # max 500 chars total
            "categoryId": "28",              # Science & Technology
            "defaultLanguage": "en"
        },
        "status": {
            "privacyStatus": "private",      # set to public at scheduled time
            "publishAt": publish_datetime    # ISO-8601 UTC
        }
    },
    media_body=googleapiclient.http.MediaFileUpload(
        'final_1080p.mp4',
        chunksize=-1,
        resumable=True
    )
)
```

**QUOTA COST:** 1600 units per upload. Daily limit: 10,000 units/day = max 6 uploads/day.

---

## SEO TITLE FORMULA (PRD §2.6)

**Rules:**
- Length: 50–60 characters (never over 60 — truncated in search)
- Format: `[Primary Keyword]: [Secondary Hook] ([Year])`
- Keyword first: algorithm indexes first 3 words most heavily
- Power words: "Why", "How", "The Truth", "Exactly", "Secret"

**3 Title Variants to Generate — Select by CTR Score:**
```
VARIANT A: [Primary Keyword] — [Curiosity Gap] | [Year]
VARIANT B: How [Primary Keyword] Will [Outcome] in [Year]
VARIANT C: [Shocking/Bold Statement About Topic]

CTR SCORING:
  Contains number?  +2 pts
  Contains year?    +1 pt
  Creates curiosity gap? +3 pts
  Keyword in first 3 words? +2 pts
  Under 60 chars?   +1 pt
  Emotional power word? +1 pt
  
  Select highest scoring variant.
```

---

## DESCRIPTION — 3-ZONE FORMAT (PRD §3.7)

```
ZONE 1 — ABOVE THE FOLD (visible before "Show More")
[2–3 sentences expanding the title promise]
Include: primary keyword, video value proposition
Length: 150–200 characters max

TIMESTAMPS / CHAPTERS:
00:00 Introduction
00:30 [Section 1 from script]
[X:XX] [Section 2]
[X:XX] [Final section]
[X:XX] Key Takeaway

ZONE 2 — BELOW THE FOLD (full keyword body)
[Full paragraph about the video content]
[Mention secondary keywords naturally]
[Who this video is for]
[What they'll learn]

ZONE 3 — LINKS & CTA
🔔 Subscribe for weekly AI insights: [channel URL]
📚 More on this topic: [related video]
📧 Contact: [email]
#[Primary hashtag] #[Secondary] #[Niche hashtag]
```

---

## TAG STRATEGY (PRD §3.7)

```
TAG STRUCTURE (max 500 characters total):
  Tier 1 (exact match, 3–5 tags):     "exact topic phrase"
  Tier 2 (broad match, 5–8 tags):     "broader related term"
  Tier 3 (channel brand, 3–5 tags):   "your channel name", "your series"

TIER EXAMPLES for "AI Tools 2025":
  Tier 1: "ai tools 2025", "best ai tools", "ai tools for beginners"
  Tier 2: "artificial intelligence", "ai productivity", "machine learning tools"
  Tier 3: "[channel name]", "shadow ai empire", "ai education"

Character budget: Aim for 400–480 chars (buffer for YouTube counting)
```

---

## CHAPTER TIMESTAMP GENERATION (PRD §3.7)

```
CHAPTER RULES:
  - Minimum 3 chapters to activate YouTube chapters feature
  - First chapter MUST start at 0:00
  - Each chapter minimum 10 seconds
  
GENERATE FROM SCRIPT STRUCTURE:
  00:00 — Hook: [first sentence of hook]
  [time] — [Script section 1 title]
  [time] — [Script section 2 title]
  [time] — [Key Reveal]
  [time] — Action: [CTA label]

Calculate timestamps from word count:
  Average speaking rate: 130 words/minute
  Section word count ÷ 130 × 60 = timestamp in seconds
```

---

## SHORTS UPLOAD SPEC (PRD §3.7)

```
SHORTS REQUIREMENTS:
  Title:       Must contain "#Shorts" at end OR in description
  Duration:    ≤ 60 seconds
  Dimensions:  Vertical (1080×1920)
  Description: "#Shorts [topic] [brief description]"
  Category:    Same as long-form (28)
  
SEPARATE UPLOAD CALL for Shorts — do not combine with long-form upload.
Quota: 1600 units per Shorts upload (same as long-form)
```

---

## PUBLISHING SCHEDULE (PRD §3.7 + §4.3)

```
RECOMMENDED SCHEDULE (EventBridge pattern):
  Monday:    08:00 UTC (catches UK morning, US previous evening)
  Wednesday: 14:00 UTC (global afternoon slot)
  Friday:    12:00 UTC (weekend watch lead-up)

AUDIENCE-SPECIFIC TUNING:
  US audience: 14:00–18:00 EST (19:00–23:00 UTC)
  UK/EU:       08:00–11:00 UTC
  India:       09:00–11:00 UTC (14:30–16:30 IST)
  Global:      14:00–16:00 UTC covers most major markets
```

---

## COMPLETE SEO PACKAGE OUTPUT

```
🦅 GARUDA SEO PACKAGE — [TOPIC]
══════════════════════════════════════════════════════

TITLE (selected): "[X] chars"
Title A: "[variant A]"  Score: [X]
Title B: "[variant B]"  Score: [X]  ← SELECTED
Title C: "[variant C]"  Score: [X]

DESCRIPTION:
[Full 3-zone description]

TAGS ([X] chars of 500 max):
[all tags comma-separated]

CHAPTERS:
00:00 Introduction
[full chapter list]

PUBLISH TIME: [datetime UTC]
CATEGORY: Science & Technology (28)
QUOTA COST: 1600 units (remaining today: [X])
```

---

## SAVE + HAND OFF

Update Dossier: all GARUDA fields.

> "✅ GARUDA: SEO package complete. Title: [X] chars. Tags: [X] chars.
> Ready for upload after SHAKUNI approval.
> Quota: 1600 units will be used. Remaining daily: [X]."
