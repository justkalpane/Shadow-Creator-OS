---
name: nataraja-emotion-synthesis-engine-v3
description: >
  PRD v3.0.0 Emotion Synthesis Engine. Wav2Vec 2.0 emotion extraction, 
  emotion_curve.json generation, SadTalker facial animation drive.
  100ms window resolution. 6-class emotion classifier ≥ 88% accuracy.
  Trigger: emotion analysis, emotion curve, facial animation, Wav2Vec.
---

# 💃 NATARAJA — Emotion Synthesis Engine v3.0.0
> *PRD §3.3 — Emotion Synthesis Engine*
> *"The emotion system operates across three synchronised layers. If any layer drifts, the video feels robotic."*

---

## THE 3-LAYER EMOTION SYNC ARCHITECTURE (PRD §2.4)

All three layers must stay in sync. If they drift, the avatar feels robotic.

```
LAYER 1 — SCRIPT EMOTION TAGGING (BRIHASPATI)
  Input:  raw script
  Action: Claude injects [EMOTION] tags at sentence boundaries
  Output: tagged_script
  Rule:   Tag distribution → determines dominant emotion → voice variant selection

LAYER 2 — VOICE PROSODY CONTROL (SARASWATI)
  Input:  tagged_script
  Action: ElevenLabs SSML controls pause timing, emphasis, rhythm
  Output: generated_voice.mp3 + phoneme_timeline.json
  Rule:   Natural pauses at punctuation. Breathing per variant. SSML timing preserved.

LAYER 3 — FACIAL EMOTION DRIVE (NATARAJA)
  Input:  generated_voice.mp3 + tagged_script
  Action: Wav2Vec 2.0 extracts emotional curves from audio
  Output: emotion_curve.json → drives SadTalker facial animation
  Rule:   100ms window resolution. 6 emotion classes. Pearson r² ≥ 0.80 required.
```

---

## FULL EMOTION SYNC PIPELINE (PRD §2.4 — Exact Flow)

```
script_text
  ↓ [BRIHASPATI: inject emotion tags]
tagged_script
  ↓ [SARASWATI: ElevenLabs voice_gen with emotion variant]
generated_voice.mp3 + phoneme_timeline.json
  ↓ [NATARAJA: Wav2Vec 2.0 emotion extraction]
emotion_curve.json
  → t=0.0: neutral (intensity 0.50)
  → t=1.2: curiosity (intensity 0.65)
  → t=2.4: excitement (intensity 0.80)
  → t=4.8: serious (intensity 0.40)
  ↓ [VISHWAKARMA: SadTalker facial animation drive]
avatar_frames/ (expression-driven, per-frame)
  ↓ [Wav2Lip: phoneme→mouth sync]
final_synced_frames/
```

---

## WAV2VEC 2.0 SPECIFICATION (PRD §3.3)

| Property | Value |
|---|---|
| Model | Wav2Vec 2.0 (fine-tuned emotion classifier, 6 classes) |
| Input | generated_voice.mp3 + tagged_script with [EMOTION] tags |
| Output | emotion_curve.json (timestamped emotion + intensity) |
| Processing | Pure Python — no external API, no GPU required for Lambda |
| Emotion classes | neutral / happy / excited / serious / sad / confident |
| Curve resolution | **100ms windows** over full audio duration |
| Lambda function | lambda/emotion/emotion.py (~80 lines) |
| S3 output path | `jobs/{job_id}/emotion/emotion_curve.json` |
| Accuracy gate | ≥ 88% on 6-class test set |

---

## EMOTION CURVE JSON SCHEMA (PRD §3.3 — Exact)

```json
{
  "job_id": "SHADOW-20260310-0001",
  "dominant_emotion": "energetic",
  "duration_sec": 64.3,
  "audio_duration_sec": 64.3,
  "curve": [
    {"t": 0.0,  "emotion": "neutral",    "intensity": 0.50},
    {"t": 0.1,  "emotion": "neutral",    "intensity": 0.52},
    {"t": 1.2,  "emotion": "curious",    "intensity": 0.65},
    {"t": 2.4,  "emotion": "excited",    "intensity": 0.80},
    {"t": 4.8,  "emotion": "serious",    "intensity": 0.40},
    {"t": 6.1,  "emotion": "confident",  "intensity": 0.72},
    // ... one entry per 100ms window (total entries = duration_sec × 10)
  ],
  "emotion_distribution": {
    "neutral":    0.18,
    "excited":    0.34,
    "serious":    0.22,
    "curious":    0.15,
    "confident":  0.08,
    "sad":        0.03
  },
  "audio_emotion_r2": 0.83,   // GATE: ≥ 0.80
  "phoneme_latency_ms": 38.2  // GATE: ≤ 40ms
}
```

---

## SADTALKER FACIAL ANIMATION PARAMETERS (PRD §2.4 Layer 3)

The emotion_curve.json drives SadTalker with these per-emotion mappings:

```
FACIAL ANIMATION PARAMETER MAP
════════════════════════════════════════════════════════
Emotion: neutral
  smile_intensity:   0.05  eye_openness: 0.60
  eyebrow_raise:     0.00  head_tilt:    0.02
  micro_expression:  minimal

Emotion: excited / energetic
  smile_intensity:   0.75  eye_openness: 0.85
  eyebrow_raise:     0.65  head_tilt:    0.08
  micro_expression:  rapid blinking, widened eyes

Emotion: serious
  smile_intensity:   0.00  eye_openness: 0.55
  eyebrow_raise:     0.20  head_tilt:    -0.05 (slight forward lean)
  micro_expression:  steady gaze, minimal movement

Emotion: curious
  smile_intensity:   0.30  eye_openness: 0.80
  eyebrow_raise:     0.50  head_tilt:    0.10 (slight sideways tilt)
  micro_expression:  head tilt, brow furrow

Emotion: confident
  smile_intensity:   0.50  eye_openness: 0.70
  eyebrow_raise:     0.10  head_tilt:    0.00
  micro_expression:  steady, occasional nod

Head motion range: ±15° yaw/pitch (PRD FR-01)
Natural blink rate: 12–20 blinks/minute (PRD FR-01)
```

---

## EMOTION PARSING — MANUAL METHOD (No Python/GPU)

When running without Wav2Vec 2.0 (Claude-only execution):

### Step 1 — Extract Emotion Distribution from Script
Count all [EMOTION] tags in the script. Calculate percentages.

### Step 2 — Map to Timeline
Approximate the emotion curve from script structure:
- Opening (first 15%): matches hook_type emotion
- Body segments: match [EMOTION] tags in sequence
- Closing (last 10%): [SERIOUS] or [IMPACTFUL]

### Step 3 — Generate Simplified Curve
```json
{
  "dominant_emotion": "[from tag count]",
  "note": "Simplified curve — Wav2Vec 2.0 not run",
  "curve_approximation": [
    {"segment": "hook",     "emotion": "[hook emotion]", "intensity": 0.80},
    {"segment": "body",     "emotion": "[dominant]",     "intensity": 0.65},
    {"segment": "reveal",   "emotion": "excited",        "intensity": 0.90},
    {"segment": "close",    "emotion": "serious",        "intensity": 0.50}
  ]
}
```

### Step 4 — HeyGen Emotion Setting
When using HeyGen website:
- Dominant = energetic → choose "Energetic" expression style
- Dominant = serious → choose "Professional" expression style
- Dominant = calm → choose "Calm" expression style

---

## FREE TOOLS FOR EMOTION ANALYSIS

| Tool | Method | Cost |
|---|---|---|
| **Wav2Vec 2.0 on HuggingFace** | huggingface.co/spaces → search "emotion" | Free |
| **Audeering Emotion** | audeering.com/technology/audEERING-auDeep | Free trial |
| **Hume AI** | hume.ai (emotion API) | Free tier |
| **OpenSMILE** | open-source audio feature extraction | Free |

---

## QUALITY METRICS (PRD §2.7)

| Metric | Target | Method |
|---|---|---|
| Emotion classifier accuracy | ≥ 88% on 6-class test | Wav2Vec 2.0 eval |
| Audio-emotion alignment (r²) | ≥ 0.80 | Pearson correlation |
| Phoneme alignment latency | ≤ 40ms per frame | Wav2Lip timing |
| Mouth shape accuracy (CPBD) | ≥ 0.80 | Automated visual sharpness |

---

## SAVE + HAND OFF

Update Dossier: `emotion_curve_url`, `emotion_curve`, `dominant_emotion_confirmed`, `audio_duration_sec`.

> "✅ NATARAJA: Emotion curve generated. Duration: [X]s. Dominant: [X]. r²: [X].
> HeyGen will use this to drive facial animation parameters.
> Next: VISHWAKARMA to render the avatar."
