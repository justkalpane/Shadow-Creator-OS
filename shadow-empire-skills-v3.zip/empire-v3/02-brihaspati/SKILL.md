---
name: brihaspati-script-engine-v3
description: >
  PRD v3.0.0 compliant script engine. Generates emotion-tagged, SSML-marked, 
  Flesch-validated scripts using Bedrock Claude Sonnet prompt architecture.
  3 A/B hook variants. CTR predictor selects winner. 5 hook types.
  Trigger: write script, create content, draft video, make script.
---

# 🕉 BRIHASPATI — Script Engine v3.0.0
> *PRD §3.5 — Autonomous Content Engine*
> *"HOOK → SIMPLE_EXPLANATION → REAL_EXAMPLE → VISUAL_ILLUSTRATION → FUTURE_PREDICTION"*

---

## BEDROCK SCRIPT GENERATION PROMPT ARCHITECTURE (PRD §3.5 — Exact)

This is the system prompt Claude uses internally when writing every script:

```
SYSTEM: You are an expert AI education scriptwriter for a YouTube channel
explaining AI to general audiences. Write in conversational, simple English.

RULES:
1. Start with one of three hook types: [CURIOSITY_GAP | SHOCK_STAT | OPEN_LOOP]
2. Inject [EMOTION] tags at sentence boundaries:
   [ENERGETIC] [CALM] [SERIOUS] [IMPACTFUL] [CONSPIRATORIAL] [NEUTRAL]
3. Every [IMPACTFUL] sentence → follow with <break time="0.5s"/>
4. Every [SERIOUS] sentence → follow with <break time="0.3s"/>
5. Total length: {target_word_count} words
6. End with explicit call-to-action (subscribe/comment/like)
7. Reading level: Flesch score ≥ 60 (Grade 8 maximum)
8. Emotion tag density: minimum 1 tag per 3 sentences
9. Never use same tag 3+ times consecutively
10. First word cannot be: "I", "So", "Well", "Today"
```

---

## SCRIPT FORMULA (PRD §3.5)

```
HOOK (first 30 sec) → who stays or leaves is decided here
  ↓
PROMISE → tell them exactly what they'll learn
  ↓
SIMPLE_EXPLANATION → explain concept in plain language
  ↓
REAL_EXAMPLE → prove it with a story, case study, or statistic
  ↓
VISUAL_ILLUSTRATION → paint a mental picture they can see
  ↓
FUTURE_PREDICTION → where is this going in 6–12 months
  ↓
CALL_TO_ACTION → subscribe / comment / watch next
```

---

## 5 CTR HOOK TYPES (PRD §2.6)

| Hook Type | Template | CTR Impact |
|---|---|---|
| `CURIOSITY_GAP` | "This AI capability was quietly deployed in [INDUSTRY] last month." | High |
| `OPEN_LOOP` | "By the end of this video, you will know exactly how to [OUTCOME]." | High |
| `SHOCK_STAT` | "[STATISTIC] of [PROFESSION] jobs will look different by [YEAR]." | Very High |
| `CONSPIRATORIAL` | "What most people don't realise about [AI TOPIC]..." | Very High |
| `IDENTITY` | "If you work in [FIELD], this changes everything for you." | Targeted High |

**Generate 3 variants, pick the highest CTR prediction based on niche.**

---

## WORD COUNT TARGETS

| Format | Word Count | ElevenLabs Duration | YouTube Length |
|---|---|---|---|
| Short / Shorts | 150–200 words | ~60–90 sec | 60–90 sec |
| Medium / Tutorial | 1,100–1,300 words | ~8–10 min | 8–12 min |
| Long / Deep Dive | 2,000–2,400 words | ~14–18 min | 15–20 min |

---

## EMOTION TAGS — FULL SPECIFICATION (PRD §2.3)

| Tag | ElevenLabs Variant | Intensity | SSML After |
|---|---|---|---|
| `[ENERGETIC]` | energetic | 0.80 | none |
| `[IMPACTFUL]` | energetic | 0.90 | `<break time="0.5s"/>` |
| `[CALM]` | calm | 0.30 | none |
| `[CONSPIRATORIAL]` | calm | 0.50 | none |
| `[SERIOUS]` | serious | 0.40 | `<break time="0.3s"/>` |
| `[NEUTRAL]` | master | 0.50 | none |

**Dominant Emotion Rule:** Count tags → most frequent tag type → that emotion's ElevenLabs variant is selected for generation. Tie → use `master`.

---

## SSML VOICE CONTROL MARKERS (PRD §2.4 Layer 2)

```
Pause after impactful statements:  <break time="0.5s"/>
Pause after serious statements:    <break time="0.3s"/>
Pause between list items:          <break time="0.3s"/>
Word emphasis:                     <emphasis level="strong">word</emphasis>
Sentence rhythm enforcement:       Natural pause at commas/periods
Breathing patterns:                Calibrated per ElevenLabs variant
```

**CRITICAL:** Chunk boundary rule — NEVER split an SSML `<break>` or `<emphasis>` tag across a 4,800-char chunk boundary.

---

## SCRIPT EXECUTION STEPS

### Step 1 — Load Context
Read from `_outputs/current-job.md`: topic, hook_type, dominant_emotion, target_length, key_points.
If missing, ask user: topic + length preference.

### Step 2 — Generate 3 Hook Variants
Using hook formulas above. Present as:
```
HOOK A [CURIOSITY_GAP]: "[hook text]"  — Predicted CTR: X%
HOOK B [SHOCK_STAT]:    "[hook text]"  — Predicted CTR: X%  
HOOK C [CONSPIRATORIAL]:"[hook text]"  — Predicted CTR: X%
```
Ask user to select or auto-select highest CTR.

### Step 3 — Write Full Tagged Script
Follow BEDROCK PROMPT ARCHITECTURE rules exactly.
Apply emotion tags at sentence boundaries.
Apply SSML markers after [IMPACTFUL] and [SERIOUS].

### Step 4 — Validation Checklist
```
□ Word count in range for selected format
□ Flesch readability ≥ 60 (read aloud test: does it sound like normal speech?)
□ First sentence is the chosen hook
□ No sentence > 25 words
□ Emotion tags: ≥ 1 per 3 sentences
□ No same tag 3× in a row
□ [IMPACTFUL] always has <break time="0.5s"/> after
□ Ends with explicit CTA
□ Script NOT > 4800 chars if single chunk; split if needed
□ Chunk boundaries fall at paragraph ends, never mid-sentence
```

### Step 5 — Deliver Script

```
📜 SCRIPT — [TOPIC]
════════════════════════════════════════
Format: [Short/Medium/Long] | Words: [X] | Duration: ~[X] min
Dominant Emotion: [X] → ElevenLabs Variant: [X]
Hook Selected: [HOOK_TYPE]
Chunks Required: [X] (split at chars: [split_point])
────────────────────────────────────────

[FULL TAGGED + SSML SCRIPT HERE]

────────────────────────────────────────
EMOTION ANALYSIS:
  ENERGETIC: [X]  IMPACTFUL: [X]  CALM: [X]
  CONSPIRATORIAL: [X]  SERIOUS: [X]  NEUTRAL: [X]
  DOMINANT: [X] → Voice variant: [X]
```

### Step 6 — Save + Hand Off
Save script to `_outputs/current-job.md`.
> "✅ Script ready. [X] words. [X] chunks for ElevenLabs.
> Next: SARASWATI for voice generation. Or BRAHMA for background prompts."
