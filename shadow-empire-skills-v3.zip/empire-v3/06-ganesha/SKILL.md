---
name: ganesha-analytics-learning-v3
description: >
  PRD v3.0.0 Analytics Learning Engine. YouTube Analytics API daily pull.
  CTR ≥6% / Watch Time ≥50% targets. 4-weight feedback loop updating BRIHASPATI,
  SARASWATI, SANJAY/AGNI, NARADA. Performance-to-improvement pipeline.
  Trigger: check analytics, video performance, what worked, analytics report.
---

# 🐘 GANESHA — Analytics Learning Engine v3.0.0
> *PRD §3.8 — Analytics Learning Engine*
> *"Lord of Intellect. He removes obstacles by understanding them first."*

---

## PERFORMANCE TARGETS (PRD §2.7)

| Metric | Target | Excellent | Action if Below |
|---|---|---|---|
| CTR (Click-Through Rate) | ≥ 6% | ≥ 8% | Update thumbnail → MAYA |
| Watch Time % | ≥ 50% | ≥ 65% | Fix pacing → AGNI/SANJAY |
| Avg view duration | video-length dependent | ≥ 60% of duration | Fix hook → BRIHASPATI |
| Subscriber conversion | ≥ 0.5% of viewers | ≥ 1% | Strengthen CTA |
| Likes ratio | ≥ 2% of views | ≥ 3% | Improve content quality |
| Comments | engagement signal | high = algorithm boost | Add discussion prompt |

---

## ANALYTICS PULL SCHEDULE (PRD §3.8)

```
PULL INTERVALS AFTER PUBLISH:
  2 hours:   Initial CTR signal (thumbnail + title working?)
  24 hours:  First watch time reading (retention pattern visible)
  7 days:    Full performance picture (algorithm promotion window)
  28 days:   Definitive performance data for learning weights

YouTube Analytics API metrics to pull:
  views, estimatedMinutesWatched, averageViewPercentage,
  averageViewDuration, subscribersGained, likes, comments,
  clickThroughRate, impressions, audienceWatchRatio (retention graph)
```

---

## RETENTION GRAPH ANALYSIS

```
RETENTION GRAPH INTERPRETATION:
  Drop-off in first 30 sec → Hook failed → weight: BRIHASPATI hook type
  Drop-off at 30–60 sec    → Promise failed → BRIHASPATI structure
  Gradual decline          → Pacing too slow → AGNI cut frequency
  Cliff at specific point  → That section is weak → BRIHASPATI that section
  Strong retention plateau → This emotion/format works → reinforce

KEY INFLECTION POINTS:
  t=0–0.1 (first 10%):  audience retention must stay > 70%
  t=0.1–0.5 (10–50%):   gradual decline acceptable, < 15% drop
  t=0.5–0.9 (50–90%):   retention plateau = content is delivering value
  t=0.9–1.0 (last 10%): spike = strong CTA working
```

---

## FEEDBACK WEIGHT SYSTEM (PRD §3.8)

```
FEEDBACK WEIGHTS — Update these 4 modules based on performance:

WEIGHT 1 → BRIHASPATI (Hook template)
  IF video CTR > 8%:         hook_type[used] weight += 0.1
  IF video CTR < 4%:         hook_type[used] weight -= 0.1
  IF avg_retention > 60%:    script_formula weight += 0.1
  → Next BRIHASPATI call uses updated hook_type_weights

WEIGHT 2 → SARASWATI (Emotion variant)  
  IF watch_time_pct > 60%:   voice_variant[used] weight += 0.1
  IF watch_time_pct < 40%:   voice_variant[used] weight -= 0.1
  → Next SARASWATI call prioritises higher-weight variants

WEIGHT 3 → AGNI/SANJAY (Cut frequency)
  Read retention graph inflection points:
  IF drop > 20% at 3-sec interval:  cut_frequency += 0.5/sec
  IF drop < 5% sustained:           cut_frequency steady
  → Next AGNI call adjusts zoom_cut density

WEIGHT 4 → NARADA (Topic category)
  IF subscriber_conversion > 1%:    topic_category weight += 0.1
  IF likes_ratio < 1%:              topic_category weight -= 0.05
  → Next NARADA research prioritises higher-weight categories

UPDATE RULE: Learning rate = 0.1 (gradual, prevents overcorrection)
MINIMUM VIDEOS: 10 videos before weights are statistically meaningful
RESET RULE: Weights reset if channel persona changes
```

---

## GANESHA PERFORMANCE REPORT FORMAT

```
🐘 GANESHA PERFORMANCE REPORT — [VIDEO TITLE]
════════════════════════════════════════════════
Published: [date] | Pull date: [date] | Age: [X days]

PERFORMANCE METRICS:
  Views:            [X,XXX]
  Impressions:      [X,XXX]
  CTR:              [X.X]%  [TARGET ≥6%] [✅/⚠/❌]
  Watch Time %:     [X.X]%  [TARGET ≥50%] [✅/⚠/❌]
  Avg View Duration: [X:XX] of [X:XX] total
  Subscribers Gained: [+X]
  Likes:            [X] ([X.X]% ratio)
  Comments:         [X]

RETENTION ANALYSIS:
  Drop-off points: [timestamps where notable drops occur]
  Strong zones:    [timestamps where retention stays flat or rises]
  Diagnosis:       [What caused the main drop-off]

FEEDBACK WEIGHTS UPDATED:
  BRIHASPATI hook_type [[hook_type]]: [previous] → [new]
  SARASWATI voice_variant [[variant]]: [previous] → [new]
  AGNI cut_frequency: [previous] → [new] cuts/3sec window
  NARADA topic_category [[category]]: [previous] → [new]

RECOMMENDATIONS FOR NEXT VIDEO:
  1. [Specific actionable change]
  2. [Specific actionable change]
  3. [Specific actionable change]
════════════════════════════════════════════════
```

---

## SAVE + HAND OFF

Update Dossier: `performance_data`, `feedback_weights`.

> "✅ GANESHA: Analytics logged. Weights updated.
> CTR: [X]%. Watch time: [X]%. [Diagnosis in one sentence].
> Weights have been updated for the next video production cycle."
