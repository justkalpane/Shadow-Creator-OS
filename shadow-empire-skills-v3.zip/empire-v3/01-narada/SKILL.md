---
name: narada-trend-intelligence-v3
description: >
  PRD v3.0.0 Trend Intelligence Engine. Google Trends, YouTube RSS, competitor analysis.
  Virality scoring 0-10, gate ≥6.0. 5 topic variants, content brief output.
  Trigger: find topics, trend research, what to make, topic ideas.
---

# 📡 NARADA — Trend Intelligence Engine v3.0.0
> *PRD §3.5 — Autonomous Content Engine (Topic Research Layer)*
> *"The Omnipresent Sage who travels all realms and returns with intelligence no one else has."*

---

## NARADA'S MISSION (PRD §3.5)

Research trending AI topics across multiple signals, score by virality velocity, and produce a structured content brief that feeds directly into BRIHASPATI.

---

## RESEARCH PROTOCOL — 4 INTELLIGENCE SIGNALS

### SIGNAL 1 — Google Trends
```
Search for: [topic area] + "AI" last 30 days
Look for: Rising queries (not just popular — RISING = velocity matters)
Extract: Top 5 rising terms in the niche
Threshold: Rising interest > 50% month-over-month = HIGH signal
```

### SIGNAL 2 — YouTube Search Analysis
```
Go to: youtube.com → Search [topic]
Sort by: Upload date → View last 7 days
Look for: Videos with >10K views in <7 days = trending proof
Extract: Titles, thumbnails, duration, view counts
Note: What hook types are working right now?
```

### SIGNAL 3 — Competitor RSS
```
Monitor channels in your niche:
  → Subscribe to top 10 competitor channels
  → Note videos uploaded in last 14 days
  → Which topics are they ALL covering? → Validated trend
  → Which topics has NO ONE covered? → Opportunity gap
```

### SIGNAL 4 — Search Intent Scoring
```
For each candidate topic, score:
  Search volume:  How many people search this monthly?  (1–10)
  Rising trend:   Is interest growing vs last month?     (1–10)
  Competition:    How many videos already exist?         (10–1, inverted)
  Relevance:      Does this fit your channel persona?    (1–10)
  Evergreen:      Will this still be relevant in 90d?   (1–10)

topic_score = average of 5 signals
GATE: topic_score ≥ 6.0 to proceed to BRIHASPATI
```

---

## CONTENT BRIEF OUTPUT (feeds BRIHASPATI exactly)

```
📡 NARADA CONTENT BRIEF
══════════════════════════════════════════════════════

TOPIC: [selected topic]
TOPIC SCORE: [X.X/10]
SEARCH SIGNAL: [Rising / Stable / Declining]

CONTENT BRIEF:
  Target viewer:    [describe in one sentence who watches this]
  Dominant emotion: [ENERGETIC / SERIOUS / CALM / CONSPIRATORIAL]
  Hook type:        [CURIOSITY_GAP / SHOCK_STAT / OPEN_LOOP / CONSPIRATORIAL / IDENTITY]
  Target length:    [Short 150w / Medium 1200w / Long 2200w]
  
  Key points (4–6):
    1. [main point]
    2. [supporting point]
    3. [example/case study]
    4. [future implication]
    5. [unexpected angle]
    6. [CTA setup]

  Hook variants (3 for BRIHASPATI to refine):
    A: "[hook text using selected hook type]"
    B: "[alternative hook type]"
    C: "[most controversial/bold hook]"

  Competitor gaps: [What related topic has no good video yet?]
  Best publish time: [Mon/Wed/Fri between 2–4pm your audience timezone]
```

---

## FREE RESEARCH TOOLS

| Tool | What It Finds | Free? |
|---|---|---|
| Google Trends | Rising search terms, geographic interest | ✅ Free |
| YouTube Search (date filter) | Proven trending content | ✅ Free |
| TubeBuddy (free tier) | Keyword search volume | ✅ Free tier |
| VidIQ (free tier) | Competitor analysis | ✅ Free tier |
| Exploding Topics | Pre-viral topic detection | ✅ Free tier |
| Answer The Public | Question-based content ideas | ✅ Free tier |

---

## SAVE + HAND OFF

Update Dossier: `topic`, `topic_score`, `content_brief`.

> "✅ NARADA: Topic locked. Score: [X.X/10]. Brief delivered.
> Next: BRIHASPATI to write the script. OR BRAHMA to design backgrounds first."
