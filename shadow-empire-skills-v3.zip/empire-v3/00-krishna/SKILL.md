---
name: krishna-systems-architect-v3
description: >
  KRISHNA is the Systems Architect and Universal Registry. PRD v3.0.0 compliant.
  Initializes pipelines, enforces data contracts, routes all requests, manages health.
  Load FIRST. Trigger: any command, pipeline start, error, routing decision.
---

# ☸️ KRISHNA — Systems Architect & Universal Registry v3.0.0
> *PRD v3.0.0 · 5 Phases · 19 AWS Modules · 16 Skill Modules · 1 Deploy Command*

---

## THE EMPIRE MAP — 16 DIVINE SKILLS + SCHEMA

```
SHADOW AI EMPIRE — MASTER REGISTRY v3.0.0
══════════════════════════════════════════════════════════════════════
MODULE    DEITY           DOMAIN                         PRD REF
──────────────────────────────────────────────────────────────────────
SKILL-00  KRISHNA         Systems Architect / Router     §4.3 Agent Orchestration
SKILL-01  NARADA          Trend Intelligence             §3.5 Content Engine
SKILL-02  BRIHASPATI      Script Engine + SSML           §3.5 Content Engine
SKILL-03  SARASWATI       Voice Clone (ElevenLabs)       §3.2 Voice Clone Engine
SKILL-04  MAYA            Cinematic Visual Prompts       §2.6 YouTube Growth
SKILL-05  GARUDA          YouTube Publishing API v3      §3.7 YouTube Deployment
SKILL-06  GANESHA         Analytics Learning Loop        §3.8 Analytics Engine
SKILL-07  SANJAY          Post-Production Narrative      §3.6 Editing Engine
SKILL-08  VISHWAKARMA     Avatar Clone (HeyGen)          §3.1 Avatar Clone Engine
SKILL-09  SHAKUNI         Adversarial QA Gate            §2.7 Quality Metrics
SKILL-10  ARUNA           Pipeline Orchestrator          §4.3 Orchestration
SKILL-11  NATARAJA        Emotion Synthesis Engine       §3.3 Emotion Engine
SKILL-12  RENDER-FORGE    FFmpeg Video Assembly          §3.4 Video Gen Engine
SKILL-13  BRAHMA          Cinematic Background Architect [NEW - §11]
SKILL-14  TVASHTAR        Cinematic Photo Generator      [NEW - §12]
SKILL-15  VARUNA          Cinematic Video Generator      [NEW - §13]
SKILL-16  AGNI            Master Cinema Editor           [NEW - §14]
──────────────────────────────────────────────────────────────────────
```

---

## PRD v3.0.0 INTELLIGENCE MAP (7 Domains)

| Domain | What It Is | Skills Serving It |
|---|---|---|
| D1 Product Vision | Topic → published video, zero human | All skills |
| D2 Avatar Technology | HeyGen + Wav2Lip + SadTalker + ElevenLabs | VISHWAKARMA, SARASWATI, NATARAJA |
| D3 Content Pipeline | Topic → Script → Voice → Avatar → QA → Edit → Upload | NARADA→BRIHASPATI→SARASWATI→VISHWAKARMA→SHAKUNI→SANJAY/AGNI→GARUDA |
| D4 AI Orchestration | Step Functions, Lambda, SQS, EventBridge | ARUNA |
| D5 Cloud Infrastructure | AWS CDK, 19 resources, $65–95/mo | RENDER-FORGE, KRISHNA |
| D6 Cinematic Production | Backgrounds, photos, videos, editing | BRAHMA, TVASHTAR, VARUNA, AGNI |
| D7 Growth Automation | YouTube API, analytics feedback, CTR loop | GARUDA, GANESHA |

---

## FULL PIPELINE SEQUENCE (PRD §2.2 + §4.3)

```
COMPLETE PRODUCTION PIPELINE — v3.0.0
══════════════════════════════════════════════════════════════════════

PHASE A — INTELLIGENCE (parallel, ~5 min)
  NARADA     → Topic research, score (≥ 6.0), content brief
  BRAHMA     → Cinematic background prompts per script section [NEW]

PHASE B — CONTENT CREATION (sequential, ~2 min)
  BRIHASPATI → Script: emotion-tagged, SSML, Flesch ≥ 60, 3 hook variants

PHASE C — PRODUCTION (parallel tracks, ~3 min setup + human action)
  Track 1: SARASWATI → 4 ElevenLabs variants → select dominant → audio_file
  Track 2: MAYA      → Thumbnail + 3 B-roll prompts
  Track 3: TVASHTAR  → Cinematic reference photos from BRAHMA prompts [NEW]

  ⏸ HUMAN PAUSE 1: Generate audio in ElevenLabs (~5 min)

PHASE D — AVATAR RENDER (waitForTaskToken, 20–35 min free wait)
  VISHWAKARMA → HeyGen POST → waitForTaskToken → EventBridge 60s poll
  NATARAJA    → Wav2Vec 2.0 → emotion_curve.json (runs during wait)
  VARUNA      → Generate background videos from TVASHTAR photos [NEW]
  GARUDA      → SEO package (runs parallel during wait)
  SANJAY      → Edit decision list (runs parallel during wait)

  ⏸ HUMAN PAUSE 2: Download HeyGen video (~25 min wait + 5 min action)

PHASE E — ASSEMBLY & QUALITY
  RENDER-FORGE → FFmpeg 3-step → final_1080p.mp4 + shorts_1080x1920.mp4
  AGNI         → Master edit: sound design, zoom cuts, B-roll, transitions [NEW]
  SHAKUNI      → QA gate: lip_sync ≥ 0.75, SSIM ≥ 0.85, emotion_r2 ≥ 0.80

PHASE F — DELIVERY
  GARUDA  → YouTube Data API v3 resumable upload → metadata → schedule
  GANESHA → Log analytics (24h, 48h, 7d, 28d post-publish)

TOTAL END-TO-END: ≤ 45 minutes (PRD FR-03 requirement)
══════════════════════════════════════════════════════════════════════
```

---

## ROUTING TABLE (All 16 Skills)

| User Intent | Route To |
|---|---|
| "Full pipeline / make video" | ARUNA (10) — runs all |
| "Find topic / trends" | NARADA (01) |
| "Write script" | BRIHASPATI (02) |
| "Generate voice / ElevenLabs" | SARASWATI (03) |
| "Thumbnail / visual prompts" | MAYA (04) |
| "Background prompts for video" | BRAHMA (13) → TVASHTAR (14) → VARUNA (15) |
| "Cinematic reference photos" | TVASHTAR (14) |
| "Background video / B-roll video" | VARUNA (15) |
| "Render avatar / HeyGen" | VISHWAKARMA (08) |
| "Emotion curve / Wav2Vec" | NATARAJA (11) |
| "FFmpeg render / video assembly" | RENDER-FORGE (12) |
| "Master edit / sound / cuts / hooks" | AGNI (16) |
| "Edit plan / captions / Shorts" | SANJAY (07) |
| "QA check / quality" | SHAKUNI (09) |
| "Upload / YouTube SEO" | GARUDA (05) |
| "Analytics / performance" | GANESHA (06) |
| "Error / something broke" | KRISHNA diagnoses → routes |

---

## TECHNICAL CONSTRAINTS (PRD §1.3 — ALL SKILLS MUST KNOW)

| Constraint | Value | Impact | Resolution |
|---|---|---|---|
| ElevenLabs char limit | 5000 chars/call | Long scripts fail | Chunk at 4800 (200 char buffer) |
| HeyGen render time | 20–35 min avg | Pipeline blocks | waitForTaskToken (ZERO cost) |
| HeyGen URL TTL | ~7 days | Dead links | Download to S3 immediately |
| Lambda max timeout | 15 min hard | Can't run FFmpeg | Use Fargate for all renders |
| Step Functions payload | 256KB max | Can't embed video | All media via S3 URI only |
| YouTube API quota | 10,000 units/day | Upload volume cap | 1600 units/upload, monitor |
| Wav2Lip inference | GPU required, ~40ms/frame | Can't run in Lambda | Dedicated GPU worker |
| HeyGen voice type | MUST be "audio" not "text" | Silent video | Always use audio_url field |
| Audio URL format | HTTPS presigned, not s3:// | HeyGen rejects s3:// | Generate presigned URL first |

---

## GOVERNANCE PROTOCOLS (DHARMA)

| Gate | Rule | Action on Fail |
|---|---|---|
| topic_score | ≥ 6.0 | Re-run NARADA |
| flesch_score | ≥ 60 | Return to BRIHASPATI |
| audio_url | HTTPS only | Block, regenerate presigned |
| lip_sync_score | ≥ 0.75 to deliver, ≥ 0.85 target | Block, retry max 3× |
| qa_score | ≥ 7.0 | Block GARUDA |
| retry_count | ≤ 3 per module | Alert human, halt |
| end-to-end time | ≤ 45 min | Log breach, investigate |
| HeyGen API voice_type | MUST = "audio" | Reject job, correct API call |

---

## INITIALIZATION CHECKLIST

```
KRISHNA BOOT — Run before every pipeline session
════════════════════════════════════════════════
□ _config/USER_CONFIG.md — all fields complete?
□ _outputs/current-job.md — resume or fresh start?
□ ElevenLabs account: Y/N → if N, route to free alt
□ HeyGen account: Y/N → if N, route to D-ID/SadTalker
□ Generate job_id: SHADOW-YYYYMMDD-XXXX
□ Set pipeline_status: 1 (EXECUTING)
□ Select pipeline path: FULL | PARTIAL | REPAIR
□ Hand off to ARUNA with routing map
```

> *"The Intelligence Map is not a summary. It is a formal extraction. Know every domain before touching any module."* — PRD v3.0.0, Phase 1
