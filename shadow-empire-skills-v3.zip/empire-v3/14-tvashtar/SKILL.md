---
name: tvashtar-cinematic-photo-generator-v3
description: >
  NEW SKILL §12. Takes BRAHMA's background briefs and generates hyper-realistic
  cinematic-grade reference photos with full 8K cinematography specifications.
  Outputs ready-to-use prompts for Midjourney v6, DALL-E 3, Stable Diffusion XL.
  These photos serve as HeyGen backgrounds and VARUNA reference frames.
  Trigger: generate reference photos, cinematic photos, background images, studio photos.
---

# 🔱 TVASHTAR — Cinematic Reference Photo Generator
> *Divine Craftsman who shapes the physical form of the universe.*
> *"If BRAHMA is the architect, TVASHTAR is the builder who makes it real."*

---

## TVASHTAR'S MISSION

Take BRAHMA's background environment briefs and transform them into:
1. **Production-ready image prompts** for AI image generators (Midjourney, DALL-E 3, SDXL)
2. **Hyper-realistic reference photos** that serve as:
   - HeyGen background images (avatar composited in front)
   - VARUNA's source frames for video generation
   - Thumbnail background elements for MAYA
   - Editorial reference for AGNI's color grading

---

## STEP 1 — READ BRAHMA'S BRIEFS

Load `background_prompts` from `_outputs/current-job.md`.
For each scene brief, TVASHTAR builds the full technical photography prompt.

---

## THE TVASHTAR PROMPT FORMULA

Every generated photo prompt is built from these exact technical layers:

```
TVASHTAR MASTER PROMPT STRUCTURE
══════════════════════════════════════════════════════════════════

[SUBJECT DESCRIPTION from BRAHMA brief]
[CAMERA HARDWARE]
[LENS + APERTURE]
[LIGHTING SETUP]
[COLOR GRADE]
[COMPOSITION RULE]
[RESOLUTION + RENDER QUALITY]
[ATMOSPHERE]
[MEDIUM]

Negative: [NEGATIVE PROMPT]
```

---

## CAMERA HARDWARE — ALWAYS USE REAL NAMES

```
CINEMA CAMERAS (use for maximum photorealism):
  "ARRI Alexa 65 cinematography"          ← epic, large format
  "Red Dragon 8K VV digital cinema"       ← sharp, vibrant
  "Sony Venice 2 digital cinema camera"   ← skin tones, warmth
  "Panavision DXL2 cinema"                ← Hollywood standard
  "Blackmagic URSA Mini Pro 12K"          ← indie cinema quality

PHOTOGRAPHY CAMERAS (for still frame reference):
  "Hasselblad H6D-400C medium format"     ← ultimate sharpness
  "Phase One IQ4 150MP back"              ← micro-texture detail
  "Leica M11 rangefinder"                 ← dreamy, filmic
  "Canon EOS R5 mirrorless"               ← modern professional

ALWAYS ADD: "native 8K rendering resolution, UHD, photorealistic"
```

---

## LENS SELECTION GUIDE

| Scene Type | Lens | Effect | Prompt Text |
|---|---|---|---|
| Wide establishing shot | 18–24mm | Vast, environmental | `Zeiss 21mm f/2.8 Milvus, ultra-wide environmental capture` |
| Standard avatar background | 35–50mm | Natural, comfortable | `Leica Summilux 35mm f/1.4, natural perspective` |
| Detail/texture close-up | 85–100mm | Compressed, intimate | `Canon 85mm f/1.2L II, beautiful subject separation` |
| Hero/authority | 50mm f/1.2 | Cinematic, shallow | `Zeiss Otus 55mm f/1.4, creamy bokeh` |
| Epic scale | 24mm Anamorphic | Widescreen cinematic | `Panavision Anamorphic 24mm, oval bokeh, lens flares` |

---

## LIGHTING SETUPS — CINEMATOGRAPHY GRADE

```
THREE-POINT STUDIO (Professional/Neutral):
  "professional three-point lighting setup, 
   key light from 45° camera-left at 5600K,
   fill light at 1/2 stop under from camera-right,
   rim/separation backlight from behind-right,
   clean even illumination, controlled shadows"

CHIAROSCURO (Dramatic/Serious):
  "extreme chiaroscuro lighting, 90% deep shadow,
   single sharp key light from 45° above-left,
   Rembrandt triangle shadow pattern,
   rich shadow detail, cinematic depth"

GOLDEN HOUR (Warm/Trust):
  "golden hour backlighting through large window,
   warm amber 3200K light spill,
   subtle lens flare artifacts,
   rich highlights, lifted shadows"

VOLUMETRIC/GOD RAYS (Epic/Tech):
  "volumetric atmospheric lighting,
   shaft of light through narrow aperture,
   dust particles caught in beam,
   deep atmospheric haze,
   god ray effect"

NEON PRACTICAL (Futuristic):
  "neon RGB practical lighting,
   teal LED strip from below-left,
   magenta accent from behind,
   deep indigo ambient fill,
   wet surface reflections,
   cyberpunk color temperature mix"

BROADCAST STUDIO:
  "bright even broadcast studio lighting,
   4-point setup with soft boxes,
   5600K daylight balanced,
   no harsh shadows,
   professional newsroom illumination"
```

---

## COLOR GRADE LIBRARY

```
TRUST/AUTHORITY:
  "deep navy blue shadows, warm white midtones,
   subtle warm highlight push, cool shadow grade"

INNOVATION/AI:
  "teal shadow tones, orange-warm skin proxy,
   high-contrast teal-orange split tone,
   electric blue accent highlights"

PREMIUM/DARK:
  "deep crushed blacks, rich shadow detail,
   gold and amber highlight push,
   velvet luxury color grade"

CLINICAL/RESEARCH:
  "clean white lift, neutral midtones,
   slight cool push in shadows,
   precise scientific color accuracy"

NOSTALGIC/STORY:
  "warm amber grade, lifted shadows,
   vintage Kodak Vision film emulation,
   subtle vignette, slightly faded"

NEON FUTURIST:
  "cyberpunk palette, electric teal #00FFCC,
   hot magenta #FF0090, deep indigo black,
   neon glow halos, rain-slicked reflections"
```

---

## COMPOSITION RULES

```
RULE OF THIRDS — Avatar occupies right third, environment fills left two-thirds:
  "rule of thirds composition, subject anchor at right power point,
   environmental depth fills frame left"

FRAME-WITHIN-FRAME — Architectural elements frame the avatar area:
  "natural architectural framing, doorway/window/structural element
   creates organic border around subject space"

LEADING LINES — Environment directs eye to avatar position:
  "strong leading lines from foreground to midground,
   converging perspective draws eye to subject zone"

SYMMETRY — Perfect bilateral balance, avatar centered:
  "perfect bilateral symmetry, central axis composition,
   balanced environment on both sides of subject"

DEPTH LAYERS — Clear foreground/midground/background separation:
  "three-layer depth composition: sharp foreground detail,
   subject in sharp midground, atmospheric background"
```

---

## STEP 2 — BUILD COMPLETE PROMPT PER SCENE

```
SCENE [N] — TVASHTAR PHOTO PROMPT
══════════════════════════════════════════════════════════════════

MIDJOURNEY v6 PROMPT:
[environment description from BRAHMA],
[camera hardware],
[lens + aperture],
[lighting setup],
[color grade],
[composition rule],
native 8K rendering resolution, UHD, photorealistic,
hyper-realistic surface textures, micro-detail rendering,
cinematic depth of field, professional photography

--ar 16:9 --v 6 --style raw --q 2

────────────────────────────────────────────────────────────────
DALL-E 3 PROMPT:
A photorealistic cinematic background photograph showing [environment],
shot with [camera] and [lens], [lighting description],
[color grade description], [composition],
8K resolution, professional cinematography, no people, no text,
avatar-ready background composition

────────────────────────────────────────────────────────────────
STABLE DIFFUSION XL PROMPT:
[full assembled prompt], photorealistic, hyperrealistic, 8k resolution,
film photography, cinematic lighting, masterpiece quality,
professional commercial photography

Negative prompt: cartoon, anime, illustration, painting, sketch,
3D render, CGI obvious, plastic, text, watermark, blur, low quality,
people, faces, person, human, avatar, subject

SDXL Settings: CFG Scale: 7.5 | Steps: 30 | Sampler: DPM++ 2M Karras
```

---

## AVATAR COMPOSITING SPEC (Pass to VISHWAKARMA)

```
AVATAR INTEGRATION REQUIREMENTS per photo:
  Scene [N]:
    Avatar position:    left-third / center / right-third
    Avatar scale:       [X]% of frame width (typically 30–40%)
    Key light direction: [angle] (must match background key light)
    Color temperature:  [Kelvin] — avatar light must match bg light
    Shadow direction:   [direction] — avatar shadow must match bg
    Foreground element: [any foreground element that overlaps avatar for depth]
```

---

## FREE TOOLS TO GENERATE

| Tool | Quality | Free Limit | Best For |
|---|---|---|---|
| **Midjourney v6** | ★★★★★ | 25 free images | Best quality backgrounds |
| **DALL-E 3 (Bing)** | ★★★★ | 15/day free | Photorealistic spaces |
| **Stable Diffusion XL** | ★★★★ | Unlimited (local) | Custom fine control |
| **Adobe Firefly** | ★★★★ | 25/month | Commercial safe |
| **Ideogram v2** | ★★★★ | 10/day free | Architecture/spaces |
| **Leonardo.ai** | ★★★★ | 150 tokens/day | Consistent style |

---

## SAVE + HAND OFF

Save reference photos and prompts to `_outputs/current-job.md` under `reference_photos`.

> "✅ TVASHTAR: [X] reference photos generated/prompted.
> Photo package ready for:
>   → VARUNA: use as reference frames for video background generation
>   → VISHWAKARMA: upload as HeyGen background image
>   → MAYA: use for thumbnail visual alignment
> Next: Run VARUNA for animated background videos."
