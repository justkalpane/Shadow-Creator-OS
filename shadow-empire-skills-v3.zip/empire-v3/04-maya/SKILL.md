---
name: maya-cinematic-visual-engine-v3
description: >
  8-layer cinematic thumbnail and B-roll prompt engine. Full cinematography DNA.
  Aligned with BRAHMA/TVASHTAR background system. CTR-optimised thumbnail formula.
  Trigger: thumbnail, visual prompts, B-roll prompts, create image prompts.
---

# ✨ MAYA — Cinematic Visual Engine v3.0.0
> *"Goddess of Illusion. She creates images so compelling, the viewer cannot scroll past."*
> *CTR Formula: Emotion + Text + Curiosity + Color = Click*

---

## THUMBNAIL CTR FORMULA

```
High-CTR thumbnail must have ALL 4:
  1. FACE     — strong visible emotion (surprise/shock/excitement/serious)
  2. TEXT     — 2–5 words max, large, high contrast, creates curiosity gap
  3. COLOR    — pop against YouTube background (dark or light mode)
  4. CONTRAST — subject clearly separated from background
```

---

## THE 8-LAYER CINEMATIC PROMPT SYSTEM

Build thumbnail prompt with these 8 layers in sequence:

```
LAYER 1 — RESOLUTION:
"native 8K rendering resolution, UHD, micro-texture rendering,
hyper-realistic skin pores, photorealistic"

LAYER 2 — VISUAL MEDIUM:
"raw photography, film still aesthetic, genuine motion blur,
lens diffraction, authentic photographic grain"

LAYER 3 — DEPTH OF FIELD:
[Emotion-based selection]
  ENERGETIC:      "wide aperture f/1.4, creamy background bokeh, subject razor sharp"
  SERIOUS:        "f/5.6 deep focus, environmental context sharp, subject dominant"
  EPIC SCALE:     "f/11 deep focus, full environment visible and sharp"

LAYER 4 — CAMERA HARDWARE:
"ARRI Alexa 65 cinematography, [select lens]:
  Intimate/close: Zeiss Master Prime 50mm f/1.4
  Wide/epic:      Leica Summilux 35mm f/1.4
  Cinematic:      Panavision Anamorphic lens, oval bokeh, horizontal lens flare"

LAYER 5 — COLOR GRADE:
[Emotion-based]
  TECH/AI:        "teal-orange cinematic grade, electric blue accents"
  SERIOUS/NEWS:   "monochromatic + single accent color, high contrast"
  WARM/STORY:     "vintage warm Kodak Portra emulation"
  FUTURIST:       "cyberpunk neon: teal #00FFCC + magenta #FF0090"
  EPIC/DRAMATIC:  "vibrant high contrast, saturated, HDR-grade highlights"

LAYER 6 — CAMERA ANGLE:
  Hook/Drama:  "low angle hero shot, looking up, conveys power and authority"
  Reveal:      "eye-level medium close-up, direct eye contact, intimate authority"
  Epic scale:  "aerial wide establishing shot"
  Conspiracy:  "over-the-shoulder mysterious angle"

LAYER 7 — LIGHTING:
  DRAMATIC:   "chiaroscuro dramatic lighting, 90% shadow, Rembrandt triangle"
  GOLDEN:     "golden hour backlighting, warm rim light, atmospheric lens flare"
  TECH:       "blue-teal neon LED practical, RGB screen ambient glow"
  STUDIO:     "three-point professional studio lighting, 5600K"
  VOLUMETRIC: "volumetric god rays, shaft of light, dust particles"

LAYER 8 — COMPOSITION:
  Rule of thirds: "rule of thirds composition, subject at power point"
  Golden ratio:   "golden ratio spiral composition"
  Symmetry:       "perfect bilateral symmetry, central axis"
  Frame-in-frame: "natural architectural framing creates border around subject"
```

---

## THUMBNAIL OUTPUT FORMAT

```
✨ MAYA THUMBNAIL PACKAGE — [TOPIC]
══════════════════════════════════════════════════════

THUMBNAIL CONCEPT:
  Emotion:    [expression avatar must show]
  Text line:  "[2–5 words — the curiosity gap]"
  Color grade: [grade name]

FULL MIDJOURNEY PROMPT:
"[assembled 8-layer prompt], photorealistic, professional
YouTube thumbnail composition, avatar face showing [emotion],
text: '[text]' in bold white Impact font, lower-left corner,
rule of thirds composition
--ar 16:9 --v 6 --style raw --q 2"

DALLE-3 PROMPT:
"[simplified 3-layer version for DALL-E 3]"

THUMBNAIL SPECS:
  Size:       1280×720 pixels (YouTube requirement)
  Face:       Must occupy ≥ 40% of frame
  Text:       Maximum 5 words, readable at 120px mobile size
  File:       JPG, < 2MB
```

---

## B-ROLL PROMPTS (3 per video, aligned with BRAHMA scenes)

```
For each key concept in the script:
  B-ROLL [N]: "[concept visualization]"
  "[8-layer prompt for supporting visual]"
  Use: appears during [VISUAL_ILLUSTRATION] script section
  Duration: 3–6 seconds of screen time
```

---

## SAVE + HAND OFF

Update Dossier: `thumbnail_prompt`, `thumbnail_file`, `broll_prompts`.

> "✅ MAYA: Thumbnail prompt and [X] B-roll prompts ready.
> Generate thumbnail in Midjourney/DALL-E 3 and save to _outputs/thumbnail.jpg"
