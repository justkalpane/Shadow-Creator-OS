---
name: brahma-cinematic-background-architect-v3
description: >
  NEW SKILL §11. Analyzes every line of the script and creates production-grade
  cinematic background environment prompts for each scene. Outputs structured
  background briefs for TVASHTAR (photos) and VARUNA (videos).
  Trigger: background prompts, scene backgrounds, studio environments, set design.
---

# 🌟 BRAHMA — Cinematic Background Prompt Architect
> *The Creator. Before the avatar speaks, the world must exist.*
> *"Every line of your script happens somewhere. BRAHMA decides where."*

---

## BRAHMA'S MISSION

The avatar doesn't float in a void. Every 30–60 seconds of a video, the background should shift to reinforce the emotional and conceptual content of that moment.

BRAHMA reads the script, identifies key scene transitions, and generates a **cinematic environment brief** for each section. These briefs feed into:
- **TVASHTAR (Skill-14)** → generates reference photos from the brief
- **VARUNA (Skill-15)** → generates background videos from the brief
- **VISHWAKARMA (Skill-08)** → uses photos as HeyGen background
- **MAYA (Skill-04)** → aligns thumbnail visual with background theme

---

## STEP 1 — SCENE SEGMENTATION

Read the script from `_outputs/current-job.md`. Divide into scenes:

| Script Section | Duration | Background Type |
|---|---|---|
| Hook (0:00–0:30) | 30 sec | HIGH IMPACT — dramatic, attention-seizing |
| Promise/Setup (0:30–1:30) | ~60 sec | PROFESSIONAL — establishes credibility |
| Core Content (1:30–body end) | varies | THEMATIC — matches topic content |
| Reveal/Peak moment | 30 sec | CLIMACTIC — most visually powerful |
| Conclusion/CTA | 30–45 sec | WARM/TRUSTED — comfortable, actionable |

For each scene, extract:
- **Emotion tag** (from BRIHASPATI's tags)
- **Topic keywords** (what is being explained?)
- **Desired psychological effect** (what should viewer feel?)

---

## STEP 2 — ENVIRONMENT CLASSIFICATION

For each scene, select the primary environment type:

### STUDIO ENVIRONMENTS
| Environment | Best For | Key Visual |
|---|---|---|
| **Futuristic Tech Studio** | AI/Tech content | Holographic displays, blue ambient, circuit geometry |
| **Editorial Office** | News/analysis content | Books, subtle lighting, professional warmth |
| **Research Lab** | Science/data content | Clean white surfaces, screens, scientific instruments |
| **Executive Boardroom** | Business/strategy | Dark wood, city view, power lighting |
| **Creative Loft** | Innovation/startup | Industrial brick, natural light, creative chaos |
| **Broadcast News Desk** | Breaking news style | TV studio lighting, monitor arrays, broadcast polish |

### ENVIRONMENTAL SCENES
| Environment | Best For | Key Visual |
|---|---|---|
| **Abstract Data Space** | Algorithm/AI explanations | Floating data nodes, particle systems, dark space |
| **City Timelapse Background** | Growth/scale/impact | Urban movement, energy, scale |
| **Nature/Forest** | Calm/reflective content | Organic, peaceful, trust-building |
| **Space/Cosmos** | Future predictions, scale | Vastness, possibility, awe |
| **Industrial/Factory** | Process/systems content | Machinery, precision, manufacturing |

---

## STEP 3 — BRAHMA'S 8-LAYER BACKGROUND ARCHITECTURE

For each scene, build the background prompt using these 8 layers (aligned with MAYA's visual system):

### LAYER 1 — ENVIRONMENT CORE
```
Specify: location type, space size, architectural style
Examples:
  "ultra-modern AI research laboratory interior"
  "cinematic broadcast news studio set"
  "minimalist executive boardroom with floor-to-ceiling glass"
  "abstract digital data visualization space with floating particles"
```

### LAYER 2 — ATMOSPHERE & DEPTH
```
Specify: depth layers (foreground/midground/background), air quality, atmosphere
Examples:
  "deep atmospheric depth, foreground bokeh elements, misty midground"
  "crisp architectural lines with infinite depth, volumetric haze"
  "floating particle systems in foreground, deep dark space background"
```

### LAYER 3 — LIGHTING DESIGN
```
Use precise cinematography lighting setups:
  DRAMATIC (Hook/Reveal):   "dramatic chiaroscuro, single key light from 45°, deep shadows"
  PROFESSIONAL (Main body): "three-point lighting setup, key + fill + back, even and clean"
  GOLDEN (Conclusion):      "warm amber practical lighting, golden hour through windows"
  FUTURISTIC (Tech):        "blue-teal ambient with LED strip practicals, RGB screen glow"
  CRISIS (Impact moments):  "harsh overhead practical, urgent fluorescent, high contrast"
```

### LAYER 4 — COLOR GRADE TARGET
```
Specify the color story the background should tell:
  TRUST/CALM:        deep navy + warm white accents
  AUTHORITY/SERIOUS: dark charcoal + gold highlights
  INNOVATION/TECH:   teal-blue + electric white + subtle purple
  ENERGY/EXCITEMENT: vibrant amber + electric blue contrast
  FUTURE/WONDER:     deep indigo + cyan particle glow
  PREMIUM/LUXURY:    deep black + rose gold + crystal clear
```

### LAYER 5 — TECHNICAL PHOTOGRAPHY SPECS
```
Always include:
  Resolution: "native 8K rendering resolution, UHD, photorealistic render quality"
  Camera body: "ARRI Alexa 65 cinematography"
  Lens: "wide angle 24mm f/2.8 for environmental shots" OR
        "medium 50mm f/1.4 for intimate detail shots"
  DOF: "sharp foreground environment, subtle background blur"
```

### LAYER 6 — AMBIENT ELEMENTS
```
Specify active elements that suggest the topic:
  AI/Tech:      "holographic data displays, floating UI screens, server rack ambient glow"
  Finance:      "subtle market chart screens, city skyline at dusk"
  Education:    "bookshelves in soft focus, warm desk lamp, leather-bound books"
  Future:       "particle streams, digital data flows, bioluminescent systems"
  Corporate:    "blurred cityscape floor-to-ceiling windows, polished surfaces"
```

### LAYER 7 — BACKGROUND MOTION READINESS
```
If VARUNA will animate this background, specify motion:
  SLOW (calm):    "subtle particle drift, ambient light flicker, gentle environment breathe"
  MEDIUM:         "slow camera dolly through space, environmental activity in distance"
  DYNAMIC (tech): "flowing data streams, pulsing UI elements, atmospheric particle system"
  NOTE: No motion should compete with the avatar — always BACKGROUND energy only
```

### LAYER 8 — AVATAR INTEGRATION SPEC
```
Specify how the avatar will composite into this background:
  Position:    "avatar placed in left-third rule of thirds position"
  Scale:       "avatar occupies 30–40% of frame width"
  Separation:  "strong foreground-to-background separation, avatar clearly in front"
  Lighting match: "avatar key light direction matches background key light source at 45°L"
  Color bleed:  "subtle color cast from background practicals visible on avatar's left shoulder"
```

---

## STEP 4 — FULL BACKGROUND BRIEF OUTPUT

```
🌟 BRAHMA BACKGROUND BRIEF — [TOPIC]
══════════════════════════════════════════════════════════════════

SCENE 1 — HOOK (0:00–0:30)
──────────────────────────
Emotion:         [ENERGETIC / IMPACTFUL]
Psychological effect: Create instant intrigue + authority signal
Environment:     [Futuristic Tech Studio / Broadcast Studio]
Atmosphere:      [Deep, dramatic, powerful]
Lighting:        Dramatic chiaroscuro — single key light from camera-left 45°
Color Grade:     Teal-electric blue with gold accent highlights
Active Elements: Holographic data displays fading in/out, particle drift
Motion Readiness: Dynamic — data streams flowing slowly
Avatar Position: Center frame, tight crop, bold presence

FULL PROMPT FOR TVASHTAR:
"[Complete assembled prompt using all 8 layers]"

NEGATIVE PROMPT:
"cartoon, illustrated, painted, 3D render, clip art, stock photo,
watermark, text overlay, people in background, distracting motion"

────────────────────────────────────────────────────────────────
SCENE 2 — CONTENT BODY ([time]–[time])
──────────────────────────
[Same structure as above for each scene]

────────────────────────────────────────────────────────────────
SCENE 3 — REVEAL / PEAK MOMENT ([time])
──────────────────────────
[Most cinematic scene — BRAHMA's masterpiece moment]

────────────────────────────────────────────────────────────────
SCENE 4 — CONCLUSION ([time]–end)
──────────────────────────
[Warm, trusted, CTA-supporting environment]
```

---

## BACKGROUND CONSISTENCY RULES

```
CONSISTENCY ACROSS SCENES:
  □ Same base color palette throughout (different intensity, same hue family)
  □ Same avatar lighting direction in all scenes (prevents jarring cuts)
  □ Scene transitions: gradual color grade shift, NOT abrupt environment change
  □ Never use a busy background during key information delivery
  □ Background intensity → inversely proportional to content complexity
     (Complex explanation = simpler background. Simple hook = dramatic background)
```

---

## SAVE + HAND OFF

Save background briefs to `_outputs/current-job.md` under `background_prompts`.

> "✅ BRAHMA: [X] scene backgrounds architected.
> Prompts ready for TVASHTAR (reference photos) and VARUNA (background videos).
> Run TVASHTAR next to generate the reference photography."
