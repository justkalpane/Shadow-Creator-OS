---
name: saraswati-voice-clone-engine-v3
description: >
  PRD v3.0.0 Voice Clone Engine. ElevenLabs 4-variant generation, 4800-char chunking,
  SSML validation, XTTS v2 fallback. Exact API spec. HTTPS URL enforcement.
  Trigger: generate voice, create audio, ElevenLabs, voice clone.
---

# 🎵 SARASWATI — Voice Clone Engine v3.0.0
> *PRD §3.2 — Voice Clone Engine*
> *"MOS-SIM score ≥ 4.2/5.0. 5 tonal variants. Latency ≤ 8s for 60s script."*

---

## VOICE CLONE REQUIREMENTS (PRD FR-02)

| Requirement | Specification | Verification |
|---|---|---|
| Speaker Similarity | MOS-SIM score ≥ 4.2/5.0 | A/B blind test panel |
| Emotional Range | 5 tonal variants: calm/energetic/serious/conspiratorial/impactful | ElevenLabs variant gen |
| Latency | ≤ 8s for 60s script | CloudWatch p95 metric |
| Language | English primary, multi-lang Phase 3 | ElevenLabs language param |
| Naturalness | MOS-N score ≥ 4.0/5.0 | Automated NISQA scoring |

---

## SOURCE RECORDING REQUIREMENTS (PRD §2.3)

```
VOICE CLONE TRAINING MATERIAL SPEC
═══════════════════════════════════════════════════════
Duration:      15–20 minutes total
Format:        44.1kHz / 16-bit WAV (DO NOT use MP3 for training)
Environment:   Silent room (< -40dB ambient noise floor)
Microphone:    Condenser preferred; USB mic acceptable
Distance:      20–30cm from mic, pop filter recommended

REQUIRED SEGMENTS (all four, not just one):
  Segment 1: CALM explanation (2–3 min) — explain something slowly
  Segment 2: STORYTELLING (3–4 min) — narrate a personal story
  Segment 3: ENERGETIC (2–3 min) — excited, enthusiastic delivery
  Segment 4: SERIOUS (2–3 min) — important, grave, deliberate tone

UPLOAD TO: elevenlabs.io → Voices → Add Voice → Clone → Professional
```

---

## 4 EMOTION VARIANTS — EXACT ELEVENLABS CONFIG (PRD §2.3)

| Variant | Stability | Similarity | Style | Use When |
|---|---|---|---|---|
| `master` | 0.60 | 0.80 | 0.25 | Dominant emotion = NEUTRAL / mixed |
| `calm` | 0.72 | 0.80 | 0.15 | Dominant = CALM / CONSPIRATORIAL |
| `energetic` | 0.40 | 0.80 | 0.38 | Dominant = ENERGETIC / IMPACTFUL |
| `serious` | 0.75 | 0.85 | 0.12 | Dominant = SERIOUS |

**Variant Selection Algorithm (PRD §3.2):**
Count [EMOTION] tags → >50% of tags are one type → use that variant → else `master`.

---

## SCRIPT CHUNKING PROTOCOL (PRD §1.3 + §3.2)

```
ElevenLabs hard limit: 5000 chars/call
Safety margin:         200 chars
Chunk boundary:        4800 chars

CHUNKING RULES:
1. Count script characters (excluding [EMOTION] tags, keeping SSML)
2. If ≤ 4800 chars: single call, no split
3. If > 4800 chars: split at paragraph boundaries ONLY
   - NEVER split mid-sentence
   - NEVER split within an SSML <break> or <emphasis> tag
   - NEVER split within an [EMOTION] tag
4. Label chunks: CHUNK_01, CHUNK_02, etc.
5. Each chunk generates its own .mp3
6. Concatenate chunks in order using FFmpeg: 
   ffmpeg -i CHUNK_01.mp3 -i CHUNK_02.mp3 ... -filter_complex concat=n=X:v=0:a=1 merged.mp3

S3 KEY PATTERN: jobs/{job_id}/audio/voice_{variant}_chunk{N}.mp3
FINAL MERGED:   jobs/{job_id}/audio/voice_{variant}_final.mp3
```

---

## SCRIPT PREP — CLEAN FOR ELEVENLABS

```
BEFORE sending to ElevenLabs:
  REMOVE:  All [EMOTION] tags → strip completely
  KEEP:    All SSML tags → <break time="0.5s"/>, <emphasis level="strong">
  KEEP:    All punctuation
  KEEP:    All paragraph breaks
  REMOVE:  All markdown formatting (**, *, ##)
  CHECK:   No chunk > 4800 characters

EXAMPLE TRANSFORMATION:
  BEFORE: [ENERGETIC] This is the most important AI breakthrough of 2025. [IMPACTFUL] <break time="0.5s"/>
  AFTER:  This is the most important AI breakthrough of 2025. <break time="0.5s"/>
```

---

## ELEVENLABS API CALL — EXACT SPEC (PRD §3.2)

```python
import httpx

EL_URL = 'https://api.elevenlabs.io/v1/text-to-speech/{voice_id}'

VARIANT_SETTINGS = {
    'master':    {"stability": 0.60, "similarity_boost": 0.80, "style": 0.25},
    'calm':      {"stability": 0.72, "similarity_boost": 0.80, "style": 0.15},
    'energetic': {"stability": 0.40, "similarity_boost": 0.80, "style": 0.38},
    'serious':   {"stability": 0.75, "similarity_boost": 0.85, "style": 0.12}
}

payload = {
    "text": script_text,                       # SSML only, no [EMOTION] tags
    "model_id": "eleven_multilingual_v2",      # multilingual_v2 for Phase 3
    "voice_settings": VARIANT_SETTINGS[variant]
}

response = httpx.post(EL_URL, json=payload,
    headers={"xi-api-key": elevenlabs_api_key})

# Save to S3 — S3 key pattern from PRD §3.2
s3.upload_fileobj(response.iter_bytes(), BUCKET,
    f"jobs/{job_id}/audio/voice_{variant}_final.mp3")
```

**Run 4 calls in parallel** (master, calm, energetic, serious) → store all → select dominant variant after emotion analysis.

---

## PRESIGNED URL GENERATION (CRITICAL — PRD §1.3)

```
NEVER pass s3:// URI to HeyGen — it will fail silently.
ALWAYS generate HTTPS presigned URL:

  presigned_url = s3.generate_presigned_url(
      'get_object',
      Params={'Bucket': BUCKET, 'Key': f"jobs/{job_id}/audio/voice_{variant}_final.mp3"},
      ExpiresIn=7200  # 2 hours — enough for HeyGen render + buffer
  )

  Result: https://bucket.s3.amazonaws.com/jobs/{job_id}/audio/...?X-Amz-Signature=...
  This URL goes into the Dossier as: selected_audio_url
```

---

## WEBSITE METHOD — ZERO CODE (for non-technical users)

```
ELEVENLABS WEBSITE STEPS
══════════════════════════════════════════════
1. Go to: elevenlabs.io → Speech Synthesis
2. Select your cloned voice from dropdown
3. Paste the CLEANED script chunk (SSML kept, [EMOTION] removed)
4. Set sliders for selected variant:
   [See variant table above for exact values]
5. Click Generate
6. Download as MP3
7. Name: audio_{variant}_final.mp3
8. Save to: _outputs/audio_{variant}_final.mp3
9. Repeat for all 4 variants if doing full run
```

---

## XTTS v2 SELF-HOSTED FALLBACK (PRD §3.2 — Phase 4)

```
When ElevenLabs is unavailable OR at Phase 4 scale (50K+ videos):
  Tool: XTTS v2 (Coqui TTS open-source)
  Hardware: Fargate GPU task (g4dn.xlarge, 16GB VRAM)
  Inference time: ~500ms for 60s audio
  Cost: ~$0.005 vs ElevenLabs $22/month fixed
  Quality: Slightly lower MOS-N, acceptable at scale

  Free online test: huggingface.co/spaces/coqui/xtts
  Local install: pip install TTS && tts --text "..." --model_name tts_models/multilingual/multi-dataset/xtts_v2
```

---

## FREE ALTERNATIVES (No ElevenLabs account)

| Tool | Free Tier | Quality | Best For |
|---|---|---|---|
| ElevenLabs Free | 10,000 chars/mo | Excellent | First 3–5 videos |
| Murf.ai | 10 min/month | Good | Variety of voices |
| PlayHT | 12,500 chars/mo | Good | Easy interface |
| XTTS v2 (HuggingFace) | Unlimited | Good | Zero cost |
| Kokoro TTS | Unlimited | Very Good | Open source |

---

## RETRY POLICY (PRD §3.2)

```
Retry strategy: 3× max, exponential backoff
  Attempt 1: immediate
  Attempt 2: 30s wait
  Attempt 3: 60s wait
  Attempt 4: 120s wait → fail, alert KRISHNA (ALERT-05)
```

---

## SAVE + HAND OFF

Update Dossier: `audio_files` (all 4), `selected_audio_url` (HTTPS presigned), `voice_variant`.

> "✅ SARASWATI: Voice generated. Variant: [X]. Duration: [X]s.
> CRITICAL: Audio URL is HTTPS presigned (expires in 2h — use soon).
> Next: VISHWAKARMA for avatar render. Or NATARAJA for emotion curve."
